const fs = require('fs');
const path = require('path');
/** @type {any} */
const { parseCharX } = require('./lib/charx-parser');

function sanitizeFilename(name) {
    return name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
}

function detectContentType(buffer, filename = '') {
    if (!buffer) {
        return 'application/octet-stream';
    }

    if (buffer.length >= 12 && buffer.slice(0, 4).toString('ascii') === 'RIFF' && buffer.slice(8, 12).toString('ascii') === 'WEBP') {
        return 'image/webp';
    }

    if (buffer.length >= 8 && buffer.slice(0, 8).toString('hex') === '89504e470d0a1a0a') {
        return 'image/png';
    }

    if (buffer.length >= 2 && buffer.slice(0, 2).toString('hex') === 'ffd8') {
        return 'image/jpeg';
    }

    const ext = path.extname(filename).replace(/^\./, '').toLowerCase();
    if (['png', 'jpg', 'jpeg', 'gif', 'webp'].includes(ext)) return `image/${ext === 'jpg' ? 'jpeg' : ext}`;
    if (['mp3', 'wav', 'ogg'].includes(ext)) return `audio/${ext === 'mp3' ? 'mpeg' : ext}`;

    return 'application/octet-stream';
}

function normalizeAssetLookupKey(value) {
    return String(value || '')
        .normalize('NFKD')
        .trim()
        .replace(/^['"]|['"]$/g, '')
        .replace(/[\u2018\u2019\u02BC\uFF07`´']/g, '')
        .replace(/\.(png|jpe?g|webp|gif|apng|avif|bmp|jfif)$/i, '')
        .toLowerCase()
        .replace(/[.\s-]+/g, '_')
        .replace(/_+/g, '_')
        .replace(/^_+|_+$/g, '');
}

function getAssetLookupMatchScore(desiredLower, desiredNormalized, candidate) {
    const rawCandidate = String(candidate || '').toLowerCase();
    const normalizedCandidate = normalizeAssetLookupKey(candidate);
    if (rawCandidate === desiredLower || normalizedCandidate === desiredNormalized) {
        return 3;
    }

    if (desiredNormalized && (normalizedCandidate.endsWith(`_${desiredNormalized}`) || normalizedCandidate.startsWith(`${desiredNormalized}_`))) {
        return 1;
    }

    return 0;
}

function findImportedAssetFile(directories, name, assetPath) {
    const desired = String(assetPath || '').trim();
    if (!desired) {
        return null;
    }

    const candidates = [...new Set([
        String(name || '').trim(),
        path.parse(String(name || '')).name,
    ].filter(Boolean).map(sanitizeFilename))];

    const desiredLower = desired.toLowerCase();
    const desiredNormalized = normalizeAssetLookupKey(desired);

    const matchInDirectory = (dirPath) => {
        if (!dirPath || !fs.existsSync(dirPath) || !fs.statSync(dirPath).isDirectory()) {
            return null;
        }

        const files = fs.readdirSync(dirPath, { withFileTypes: true }).filter(entry => entry.isFile()).map(entry => entry.name);
        let bestFile = null;
        let bestScore = 0;
        for (const file of files) {
            const fileLower = file.toLowerCase();
            const baseLower = path.parse(file).name.toLowerCase();
            const score = Math.max(
                getAssetLookupMatchScore(desiredLower, desiredNormalized, fileLower),
                getAssetLookupMatchScore(desiredLower, desiredNormalized, baseLower),
            );
            if (score > bestScore) {
                bestScore = score;
                bestFile = file;
                if (score >= 3) {
                    break;
                }
            }
        }

        return bestFile ? path.join(dirPath, bestFile) : null;
    };

    for (const candidate of candidates) {
        const directMatch = matchInDirectory(path.join(directories.characters, candidate))
            || matchInDirectory(path.join(directories.characters, candidate, 'backgrounds'))
            || matchInDirectory(path.join(directories.userImages, candidate));

        if (directMatch) {
            return directMatch;
        }
    }

    return null;
}

function findCharXFile(charactersDir, userImagesDir, name) {
    const rawName = String(name || '').trim();
    if (!rawName) {
        return null;
    }

    const candidateNames = [...new Set([
        rawName,
        path.parse(rawName).base,
        path.parse(rawName).name,
        rawName.endsWith('.charx') ? rawName : `${rawName}.charx`,
    ].filter(Boolean))];
    const directoryCandidates = [...new Set(candidateNames.map(x => path.parse(String(x)).name).filter(Boolean))];

    const fileCandidates = new Set(candidateNames.map(x => String(x).toLowerCase()));
    const baseCandidates = new Set(candidateNames.map(x => path.parse(String(x)).name.toLowerCase()));
    const sanitizedCandidates = new Set(candidateNames.map(x => sanitizeFilename(path.parse(String(x)).name)));

    const directCandidateNames = [...new Set([
        ...candidateNames
            .map(x => String(x))
            .flatMap(x => x.toLowerCase().endsWith('.charx') ? [x] : [x, `${x}.charx`]),
        ...candidateNames.map(x => `${path.parse(String(x)).name}.charx`),
    ])];
    for (const candidate of directCandidateNames) {
        const directPath = path.join(charactersDir, 'charx', candidate);
        if (fs.existsSync(directPath) && fs.statSync(directPath).isFile()) {
            return directPath;
        }
    }

    const allowsExternalLookup = rawName.toLowerCase().endsWith('.charx') || [...new Set([
        ...directoryCandidates,
        ...directoryCandidates.map(x => sanitizeFilename(x)),
    ])].some(candidate => {
        if (!candidate) {
            return false;
        }

        const characterAssetDir = path.join(charactersDir, candidate);
        const userImageDir = path.join(userImagesDir, candidate);
        return (
            (fs.existsSync(characterAssetDir) && fs.statSync(characterAssetDir).isDirectory())
            || (fs.existsSync(userImageDir) && fs.statSync(userImageDir).isDirectory())
        );
    });

    const visited = new Set();
    const search = (rootDir, depth = 0) => {
        if (!rootDir || visited.has(rootDir) || depth > 4 || !fs.existsSync(rootDir)) {
            return null;
        }

        visited.add(rootDir);

        let entries = [];
        try {
            entries = fs.readdirSync(rootDir, { withFileTypes: true });
        } catch {
            return null;
        }

        for (const entry of entries) {
            const fullPath = path.join(rootDir, entry.name);
            if (entry.isFile() && entry.name.toLowerCase().endsWith('.charx')) {
                const fileLower = entry.name.toLowerCase();
                const baseLower = path.parse(entry.name).name.toLowerCase();
                const sanitizedBase = sanitizeFilename(path.parse(entry.name).name);
                if (fileCandidates.has(fileLower) || baseCandidates.has(baseLower) || sanitizedCandidates.has(sanitizedBase)) {
                    return fullPath;
                }
            }
        }

        for (const entry of entries) {
            if (!entry.isDirectory()) {
                continue;
            }

            const nestedMatch = search(path.join(rootDir, entry.name), depth + 1);
            if (nestedMatch) {
                return nestedMatch;
            }
        }

        return null;
    };

    const searchRoots = [charactersDir];
    if (allowsExternalLookup) {
        searchRoots.push(
            path.join(process.cwd(), 'public', 'scripts', 'extensions', 'risuai-importer'),
            path.join(process.cwd(), 'plugins', 'risuai-importer'),
        );
    }

    for (const rootDir of searchRoots) {
        const match = search(rootDir);
        if (match) {
            return match;
        }
    }

    return null;
}

exports.info = {
    id: 'risuai-importer',
    name: 'RisuAI Importer',
    description: 'Import and Read RisuAI .charx files natively',
};

exports.init = (router) => {
    console.log('[RisuAI Importer] Plugin Initialized (Enhanced Version)');

    const getCharsDir = (req) => req.user?.directories?.characters || path.join(process.cwd(), 'data', 'default-user', 'characters');
    const getUserImagesDir = (req) => req.user?.directories?.userImages || path.join(process.cwd(), 'data', 'default-user', 'user', 'images');

    router.post('/risu-import', async (req, res) => {
        const file = req.file;
        if (!file) return res.status(400).json({ error: 'No file uploaded.' });
        try {
            const charactersDir = getCharsDir(req);
            const fileBuffer = fs.readFileSync(file.path);
            const parsed = await parseCharX(fileBuffer);
            const charName = parsed.card?.data?.name || 'Unknown';
            let finalFilename = sanitizeFilename(charName) + '.charx';
            let outputPath = path.join(charactersDir, finalFilename);
            if (fs.existsSync(outputPath)) {
                finalFilename = sanitizeFilename(charName) + '_' + Date.now() + '.charx';
                outputPath = path.join(charactersDir, finalFilename);
            }
            fs.writeFileSync(outputPath, fileBuffer);
            try { fs.unlinkSync(file.path); } catch (e) { }
            res.json({ success: true, name: charName, filename: finalFilename });
        } catch (err) { 
            fs.appendFileSync('c:/tmp/risu-import-error.txt', String(err.stack) + '\n');
            console.error('[RisuAI Importer]', err);
            res.status(500).json({ error: err.message }); 
        }
    });

    router.get('/list', async (req, res) => {
        try {
            const charactersDir = getCharsDir(req);
            if (!fs.existsSync(charactersDir)) return res.json([]);
            const files = fs.readdirSync(charactersDir).filter(f => f.endsWith('.charx'));
            const charList = [];
            for (const file of files) {
                try {
                    const filePath = path.join(charactersDir, file);
                    const fileBuffer = fs.readFileSync(filePath);
                    const parsed = await parseCharX(fileBuffer);
                    charList.push({
                        ...parsed.card?.data,
                        name: parsed.card?.data?.name || file,
                        avatar: file,
                        is_charx: true,
                        description: parsed.card?.data?.description || '',
                        creator_notes: parsed.card?.data?.creator_notes || '',
                        tags: parsed.card?.data?.tags || [],
                    });
                } catch (e) { }
            }
            res.json(charList);
        } catch (err) { res.status(500).json({ error: err.message }); }
    });

    router.get('/get-metadata', async (req, res) => {
        const { name } = req.query;
        if (!name) return res.status(400).json({ error: 'Missing name' });
        try {
            const filePath = findCharXFile(getCharsDir(req), getUserImagesDir(req), name);
            if (!filePath || !fs.existsSync(filePath)) return res.status(404).json({ error: 'Not found' });
            const fileBuffer = fs.readFileSync(filePath);
            const parsed = await parseCharX(fileBuffer);
            const responseData = { ...parsed.card };
            if (parsed.module) {
                responseData.module = parsed.module;
            }
            res.json(responseData);
        } catch (err) { res.status(500).json({ error: err.message }); }
    });

    router.get('/get-full', async (req, res) => {
        const { name } = req.query;
        if (!name) return res.status(400).json({ error: 'Missing name' });
        try {
            const filePath = findCharXFile(getCharsDir(req), getUserImagesDir(req), name);
            if (!filePath || !fs.existsSync(filePath)) return res.status(404).json({ error: 'Not found' });
            const fileBuffer = fs.readFileSync(filePath);
            const parsed = await parseCharX(fileBuffer);
            // Don't send assets as buffers in JSON, just metadata
            const assetsMetadata = Object.keys(parsed.assets);
            res.json({
                card: parsed.card,
                module: parsed.module,
                assetKeys: assetsMetadata,
                metadata: parsed.metadata
            });
        } catch (err) { res.status(500).json({ error: err.message }); }
    });

    router.get('/get-avatar', async (req, res) => {
        const { name } = req.query;
        if (!name) return res.status(400).json({ error: 'Missing name' });
        try {
            const filePath = findCharXFile(getCharsDir(req), getUserImagesDir(req), name);
            if (!filePath || !fs.existsSync(filePath)) return res.status(404).json({ error: 'Not found' });
            const fileBuffer = fs.readFileSync(filePath);
            const parsed = await parseCharX(fileBuffer);

            let avatarAssetPath = null;
            
            // If largePortrait is explicitly false (RisuAI defaults to false for full body sprites),
            // try to serve a full-body image as the avatar so SillyTavern doesn't get a cropped bust.
            // When largePortrait is true, the `main` icon is just the portrait.
            const isLargePortrait = parsed.card?.data?.extensions?.risuai?.largePortrait === true;

            if (parsed.card && parsed.card.data && parsed.card.data.assets) {
                if (!isLargePortrait) {
                    const flatImgs = parsed.card.data.assets.filter(a => a.name.includes('_flat') || a.uri.includes('_flat'));
                    if (flatImgs.length > 0) {
                        // Prioritize clothed over nude, and neutral expressions
                        const sortedFlats = [...flatImgs].sort((a, b) => {
                            const getWeight = (name) => {
                                const lower = name.toLowerCase();
                                let w = 0;
                                if (lower.includes('nude') || lower.includes('naked') || lower.includes('nsfw')) w -= 100;
                                if (lower.includes('maid')) w += 50; // Specifically for CLEA-01 default mode
                                if (lower.includes('default') || lower.includes('neutral') || lower.includes('indifferent') || lower.includes('base') || lower.includes('normal')) w += 10;
                                return w;
                            };
                            return getWeight(b.name) - getWeight(a.name); // Higher weight comes first
                        });
                        if (sortedFlats.length > 0) avatarAssetPath = sortedFlats[0].uri.replace('embeded://', '');
                        else avatarAssetPath = flatImgs[0].uri.replace('embeded://', '');
                    } else {
                        const modeImgs = parsed.card.data.assets.filter(a => a.name.startsWith('mode_img_') || a.name === 'default');
                        const mode0 = modeImgs.find(a => a.name === 'mode_img_0');
                        if (mode0) avatarAssetPath = mode0.uri.replace('embeded://', '');
                        else if (modeImgs.length > 0) avatarAssetPath = modeImgs[0].uri.replace('embeded://', '');
                    }
                }

                if (!avatarAssetPath) {
                    const icons = parsed.card.data.assets.filter(a => a.type === 'icon');
                    const mainIcon = icons.find(a => a.name === 'main' || a.uri.includes('main') || a.name === 'iconx');
                    if (mainIcon) avatarAssetPath = mainIcon.uri.replace('embeded://', '');
                    else if (icons.length > 0) avatarAssetPath = icons[0].uri.replace('embeded://', '');
                }
            }
            
            // Fallback: search assets array for something that looks like an icon
            if (!avatarAssetPath) {
                avatarAssetPath = Object.keys(parsed.assets).find(k => k.includes('icon') || k.includes('main') || k.includes('avatar'));
            }

            if (!avatarAssetPath || !parsed.assets[avatarAssetPath]) {
                // If we still can't find an avatar inside the .charx, maybe it's not a charx but a normal png?
                // Though it reached here, so it parsed successfully.
                return res.status(404).json({ error: 'Avatar not found in charx' });
            }

            res.setHeader('Content-Type', detectContentType(parsed.assets[avatarAssetPath], avatarAssetPath));
            res.send(parsed.assets[avatarAssetPath]);
        } catch (err) { res.status(500).json({ error: err.message }); }
    });

    router.get('/asset', async (req, res) => {
        const { name, assetPath } = req.query;
        if (!name || !assetPath) return res.status(400).json({ error: 'Missing parameters' });
        try {
            const filePath = findCharXFile(getCharsDir(req), getUserImagesDir(req), name);
            if (filePath && fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
                const fileBuffer = fs.readFileSync(filePath);
                const parsed = await parseCharX(fileBuffer);

                let finalAssetPath = assetPath;
                let asset = parsed.assets[finalAssetPath];

                if (!asset) {
                    const normalizedDesired = String(finalAssetPath || '').trim().replace(/^['"]|['"]$/g, '');
                    const desiredLower = normalizedDesired.toLowerCase();
                    const desiredNormalized = normalizeAssetLookupKey(normalizedDesired);
                    const assetEntries = Array.isArray(parsed.card?.data?.assets) ? parsed.card.data.assets : [];
                    let matchedEntry = null;
                    let bestEntryScore = 0;
                    for (const entry of assetEntries) {
                        const entryName = String(entry?.name || '').trim();
                        const entryExt = String(entry?.ext || '').trim();
                        const entryNameBase = entryName ? entryName.replace(/\.[^.]+$/, '') : '';
                        const entryUri = String(entry?.uri || '').replace(/^embeded:\/\//i, '');
                        const uriBase = path.basename(entryUri);
                        const uriBaseNoExt = path.parse(uriBase).name;
                        const entryNameWithExt = entryName && entryExt && !entryName.toLowerCase().endsWith(`.${entryExt.toLowerCase()}`)
                            ? `${entryName}.${entryExt}`
                            : '';

                        const score = Math.max(...[
                            entryName,
                            entryNameBase,
                            entryNameWithExt,
                            entryUri,
                            uriBase,
                            uriBaseNoExt,
                        ].filter(Boolean).map((candidate) => getAssetLookupMatchScore(desiredLower, desiredNormalized, candidate)), 0);
                        if (score > bestEntryScore) {
                            bestEntryScore = score;
                            matchedEntry = entry;
                            if (score >= 3) {
                                break;
                            }
                        }
                    }

                    if (matchedEntry?.uri) {
                        finalAssetPath = String(matchedEntry.uri).replace(/^embeded:\/\//i, '');
                        asset = parsed.assets[finalAssetPath];
                    }
                }

                if (!asset) {
                    // Fuzzy match internally
                    // CharX assets are stored with full paths e.g., 'assets/other/image/maid_indifferent_flat.webp'
                    // But the regex 'out' string from RisuAI specifies them simply as 'maid_indifferent_flat'
                    const lowerDesired = finalAssetPath.toLowerCase();
                    const normalizedDesired = normalizeAssetLookupKey(finalAssetPath);
                    const matchedKey = Object.keys(parsed.assets).find(k => {
                        const kLower = k.toLowerCase();
                        if (kLower === lowerDesired) return true;
                        if (kLower.endsWith('/' + lowerDesired) || kLower.match(new RegExp(`/${lowerDesired}\\.[a-z0-9]+$`))) return true;
                        if (kLower.includes(`/${lowerDesired}.`) || kLower.includes(`\\${lowerDesired}.`)) return true;
                        if (getAssetLookupMatchScore(lowerDesired, normalizedDesired, path.basename(kLower)) > 0) return true;
                        if (getAssetLookupMatchScore(lowerDesired, normalizedDesired, path.parse(kLower).name) > 0) return true;
                        return false;
                    });
                    if (matchedKey) {
                        finalAssetPath = matchedKey;
                        asset = parsed.assets[matchedKey];
                    }
                }

                if (!asset) {
                    console.log(`[RisuAI Importer] Asset 404: requested '${assetPath}' in charx '${name}'.`);
                    return res.status(404).json({ error: 'Asset not found' });
                }

                res.setHeader('Content-Type', detectContentType(asset, finalAssetPath));
                res.send(asset);
                return;
            }

            const importedAssetPath = findImportedAssetFile({
                characters: getCharsDir(req),
                userImages: getUserImagesDir(req),
            }, name, assetPath);

            if (!importedAssetPath) {
                return res.status(404).json({ error: 'Asset not found' });
            }

            const importedAsset = fs.readFileSync(importedAssetPath);
            res.setHeader('Content-Type', detectContentType(importedAsset, importedAssetPath));
            res.send(importedAsset);
        } catch (err) { res.status(500).json({ error: err.message }); }
    });
};
