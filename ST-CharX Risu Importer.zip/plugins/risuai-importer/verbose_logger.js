const fs = require('fs');
const path = require('path');

const logPath = path.join(__dirname, 'debug_trace.log');

module.exports = {
    log: (msg, data = '') => {
        const timestamp = new Date().toISOString();
        const output = `[${timestamp}] [INFO] ${msg} ${data ? JSON.stringify(data) : ''}\n`;
        console.log(`[RisuAI Debug] ${msg}`, data || '');
        try { fs.appendFileSync(logPath, output); } catch (e) {}
    },
    error: (msg, err) => {
        const timestamp = new Date().toISOString();
        const stack = err?.stack || err;
        const output = `[${timestamp}] [ERROR] ${msg}: ${stack}\n`;
        console.error(`[RisuAI ERROR] ${msg}`, err);
        try { fs.appendFileSync(logPath, output); } catch (e) {}
    }
};