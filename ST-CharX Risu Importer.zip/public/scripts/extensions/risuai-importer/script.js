(function () {
    console.log('[RisuAI Importer] runtime loaded');

    const avatarBaseUrl = '/api/plugins/risuai-importer/get-avatar';
    const assetBaseUrl = '/api/plugins/risuai-importer/asset';
    const REGEX_PLACEMENT = {
        USER_INPUT: 1,
        AI_OUTPUT: 2,
        SLASH_COMMAND: 3,
        WORLD_INFO: 5,
        REASONING: 6,
    };
    const metadataCache = new Map();
    const resolvedCardDataCache = new Map();
    const RISU_OPEN_TOKEN = '%%RISU_OPEN%%';
    const RISU_CLOSE_TOKEN = '%%RISU_CLOSE%%';

    const runtimePromise = Promise.all([
        import('../../../script.js'),
        import('../../../scripts/extensions.js'),
        import('../../../scripts/chats.js'),
        import('../../../lib.js'),
        import('../../../scripts/popup.js'),
        import('../../../scripts/power-user.js'),
        import('../../../scripts/RossAscends-mods.js'),
    ]).then(([scriptApi, extensionsApi, chatsApi, libsApi, popupApi, powerUserApi, rossApi]) => ({ scriptApi, extensionsApi, chatsApi, libsApi, popupApi, powerUserApi, rossApi })).catch((error) => {
        console.warn('[RisuAI Importer] Failed to load ST runtime modules', error);
        return null;
    });

    let runtimeApi = null;
    let regexReloadScheduled = false;
    let backgroundRenderVersion = 0;
    let backgroundRenderScheduled = false;
    let backgroundRenderDeferredDuringGeneration = false;
    let lastBackgroundRenderSignature = '';
    let suppressChatObserver = 0;
    const risuPortraitSelection = new Map();
    runtimePromise.then((value) => {
        runtimeApi = value;
    });

    window.risu_context = window.risu_context || {
        variables: {
            first: '1',
            lang: 'en',
            user_role: 'student',
            emotional_level: '0',
        },
        globalVariables: {},
    };

    function getContext() {
        return window.SillyTavern && typeof window.SillyTavern.getContext === 'function'
            ? window.SillyTavern.getContext()
            : null;
    }

    function getStructuredClone(value) {
        if (typeof window.structuredClone === 'function') {
            return window.structuredClone(value);
        }

        return JSON.parse(JSON.stringify(value));
    }

    function sanitizeName(name) {
        return String(name || '').replace(/[^a-z0-9]/gi, '_').toLowerCase();
    }

    function getCardData(card) {
        return card?.data || card || {};
    }

    function getRisuData(card) {
        return card?.data?.extensions?.risuai || card?.extensions?.risuai || null;
    }

    function getRisuModule(card) {
        return getRisuData(card)?.charxModule || null;
    }

    function getRisuTriggers(card) {
        return Array.isArray(getRisuModule(card)?.trigger) ? getRisuModule(card).trigger : [];
    }

    function isLuaTriggerEditorMode(triggers) {
        return Array.isArray(triggers)
            && triggers.length === 1
            && Array.isArray(triggers[0]?.effect)
            && triggers[0].effect[0]?.type === 'triggerlua';
    }

    function getRisuTriggerEditorValue(card) {
        const triggers = getRisuTriggers(card);
        if (!triggers.length) {
            return '';
        }

        if (isLuaTriggerEditorMode(triggers)) {
            return String(triggers[0]?.effect?.[0]?.code || '');
        }

        return JSON.stringify(triggers, null, 2);
    }

    function parseRisuTriggerEditorValue(rawValue, existingTriggers = []) {
        const value = String(rawValue || '').trim();
        if (!value) {
            return [];
        }

        if (value.startsWith('[') || value.startsWith('{')) {
            const parsed = JSON.parse(value);
            return Array.isArray(parsed) ? parsed : [parsed];
        }

        if (isLuaTriggerEditorMode(existingTriggers)) {
            const next = getStructuredClone(existingTriggers);
            next[0].effect[0].code = value;
            return next;
        }

        return [{
            comment: '',
            type: 'start',
            conditions: [],
            effect: [{
                type: 'triggerlua',
                code: value,
            }],
        }];
    }

    function getCombinedBackgroundEmbedding(card) {
        const risuData = getRisuData(card) || {};
        const parts = [
            risuData.backgroundHTML,
            risuData.charxModule?.background_embedding,
        ].map(value => String(value || '').trim()).filter(Boolean);

        return [...new Set(parts)].join('\n');
    }

    function normalizeRisuHtmlAttributes(html) {
        return String(html || '')
            .replace(/\srisu-trigger\s*=\s*/gi, ' data-risu-trigger=');
    }

    function containsProtectedRisuTemplate(text) {
        const value = String(text || '');
        return value.includes(RISU_OPEN_TOKEN) || value.includes(RISU_CLOSE_TOKEN);
    }

    function protectRisuTemplateText(text) {
        if (typeof text !== 'string' || !text || containsProtectedRisuTemplate(text) || !text.includes('{{')) {
            return text;
        }

        return text
            .split('{{').join(RISU_OPEN_TOKEN)
            .split('}}').join(RISU_CLOSE_TOKEN);
    }

    function restoreRisuTemplateText(text) {
        if (typeof text !== 'string' || !text || !containsProtectedRisuTemplate(text)) {
            return text;
        }

        return text
            .split(RISU_OPEN_TOKEN).join('{{')
            .split(RISU_CLOSE_TOKEN).join('}}');
    }

    function collapseLegacyRisuAssetLoopWrappers(text) {
        return String(text || '').replace(
            /\{\{#each\s+\{\{assetlist\}\}\s+([A-Za-z0-9_]+)\}\}\s*\{\{#if\s+\{\{equal::\{\{slot::\1\}\}::([^}]*)\}\}\}\}\s*(<img\s+src="([^"]+)">)\s*\{\{\/if\}\}\s*\{\{\/each\}\}/gi,
            '$3',
        ).replace(
            /\{\{#each\s+\{\{assetlist\}\}\s+[A-Za-z0-9_]+\}\}\s*(<img\s+src="[^"]+">)\s*\}\}/gi,
            '$1',
        );
    }

    function normalizeLegacyRisuConditionalClosers(text) {
        const lines = String(text || '').split(/\r?\n/);
        const stack = [];

        for (let index = 0; index < lines.length; index++) {
            const trimmed = lines[index].trim();

            if (/^\{\{#(?:when|if)\b/i.test(trimmed)) {
                const match = trimmed.match(/^\{\{#(when|if)\b/i);
                if (match?.[1]) {
                    stack.push(match[1].toLowerCase());
                }
                continue;
            }

            if (/^\{\{\/(?:when|if)\}\}$/i.test(trimmed)) {
                const match = trimmed.match(/^\{\{\/(when|if)\}\}$/i);
                if (match?.[1] && stack[stack.length - 1] === match[1].toLowerCase()) {
                    stack.pop();
                }
                continue;
            }

            if (trimmed === '}}' && stack.length > 0) {
                lines[index] = `{{/${stack.pop()}}}`;
            }
        }

        return lines.join('\n');
    }

    function collapseLegacyRisuImageCommandWrappers(text) {
        return String(text || '')
            .replace(
                /\{\{settempvar::found::\}\}\s*\{\{settempvar::target::[^}]+\}\}\s*\{\{#each\s+\{\{assetlist\}\}\s+[A-Za-z0-9_]+\}\}\s*(?:\{\{settempvar::found::true\}\}\s*)+\}\}\s*(<img\s+cmd="[^"]+">)/gi,
                '$1',
            )
            .replace(
                /\{\{settempvar::found::\}\}\s*\{\{settempvar::target::[^}]+\}\}\s*\{\{#each\s+\{\{assetlist\}\}\s+[A-Za-z0-9_]+\}\}\s*(?:\{\{#if\s+\{\{startswith::\{\{slot::[A-Za-z0-9_]+\}\}::\{\{gettempvar::target\}\}\}\}\}\s*)?(?:\{\{settempvar::found::true\}\}\s*)+(?:\{\{\/if\}\}\s*)?\{\{\/each\}\}\s*\{\{#if\s+\{\{gettempvar::found\}\}\s*\}\}\s*(<img\s+cmd="[^"]+">)\s*\{\{\/if\}\}/gi,
                '$1',
            )
            .replace(
                /\{\{settempvar::found::\}\}\s*\{\{settempvar::target::[^}]+\}\}\s*\{\{#each\s+\{\{assetlist\}\}\s+[A-Za-z0-9_]+\}\}\s*(?:\{\{#if\s+\{\{startswith::[\s\S]*?\}\}\}\}\s*)?(?:\{\{settempvar::found::true\}\}\s*)+(?:\{\{\/if\}\}\s*)?\}\}\s*(<(?:SHP|SHX)\s*\|[^>]+>)/gi,
                '$1',
            );
    }

    function normalizeRisuDisplaySource(text) {
        let normalized = restoreRisuTemplateText(String(text || ''));
        if (!normalized) {
            return '';
        }

        normalized = normalizeLegacyRisuConditionalClosers(normalized);
        normalized = collapseLegacyRisuAssetLoopWrappers(normalized);
        normalized = collapseLegacyRisuImageCommandWrappers(normalized);
        normalized = normalized.replace(/<!--[\s\S]*?-->/g, '');
        normalized = normalized.replace(/^\s*\[Start the new session\]\s*(?:\r?\n)?/gim, '');
        normalized = normalized.replace(/\n{3,}/g, '\n\n');
        return normalized;
    }

    function protectRisuGreetingList(value) {
        if (!Array.isArray(value)) {
            return value;
        }

        return value.map(entry => protectRisuTemplateText(entry));
    }

    function protectRisuRegexScripts(scripts) {
        if (!Array.isArray(scripts)) {
            return scripts;
        }

        return scripts.map((script) => {
            if (!script || typeof script !== 'object') {
                return script;
            }

            const isRisuScript = script.risuCompat === true
                || String(script.id || '').startsWith('risu-regex-')
                || String(script.source || '').toLowerCase() === 'risuai';

            if (!isRisuScript || typeof script.replaceString !== 'string') {
                return script;
            }

            return {
                ...script,
                replaceString: protectRisuTemplateText(script.replaceString),
            };
        });
    }

    function isManagedRisuScopedScript(script) {
        return script?.risuCompat === true
            || String(script?.id || '').startsWith('risu-regex-')
            || String(script?.source || '').toLowerCase() === 'risuai';
    }

    function isLegacyRisuImageProcessScript(script) {
        const findRegex = String(script?.findRegex || '');
        const replaceString = restoreRisuTemplateText(String(script?.replaceString || ''));
        const scriptName = String(script?.scriptName || '');
        return /<img\s+src=/i.test(findRegex)
            && /chat_index/i.test(replaceString)
            && /lastmessageid/i.test(replaceString)
            && (/\$&/.test(replaceString) || /오래된 이미지 리퀘스트 제거/i.test(scriptName));
    }

    function isSimpleToggleableRisuImageScript(script) {
        const findRegex = String(script?.findRegex || '');
        const replaceString = restoreRisuTemplateText(String(script?.replaceString || ''));

        return isManagedRisuScopedScript(script)
            && /<img\s+src=/i.test(findRegex)
            && /roundedImage/i.test(replaceString)
            && /\{\{raw::\$1\}\}/i.test(replaceString)
            && !/assetlist|#each|win-classic|preview-box|lastmessageid|chat_index/i.test(replaceString);
    }

    function shouldDisableManagedRisuScopedScript(script) {
        const ruleType = String(script?.risuRuleType || '').toLowerCase();
        const findRegex = String(script?.findRegex || '');
        const replaceString = restoreRisuTemplateText(String(script?.replaceString || ''));

        if (isSimpleToggleableRisuImageScript(script)) {
            return false;
        }

        if (ruleType === 'editdisplay' || ruleType === 'editprocess' || ruleType === 'editoutput') {
            return true;
        }

        if (script?.markdownOnly === true && isManagedRisuScopedScript(script)) {
            return true;
        }

        if (isManagedRisuScopedScript(script)
            && /<img\s+src=/i.test(findRegex)
            && /chat_index/i.test(replaceString)
            && /lastmessageid/i.test(replaceString)) {
            return true;
        }

        return isLegacyRisuImageProcessScript(script);
    }

    function disableManagedRisuScopedScripts(scripts) {
        if (!Array.isArray(scripts)) {
            return scripts;
        }

        return scripts.map((script) => {
            if (!script || typeof script !== 'object') {
                return script;
            }

            if (!shouldDisableManagedRisuScopedScript(script) || script.disabled === true) {
                return script;
            }

            return {
                ...script,
                disabled: true,
            };
        });
    }

    function isLikelyMangledRisuSource(text) {
        return /\{\{#(?:when|if)[^}]*::::/i.test(String(text || ''));
    }

    function isLikelyRawRisuFirstMessage(text) {
        const restored = restoreRisuTemplateText(String(text || ''));
        return /^\s*\[[^\]\r\n]+\]/.test(restored);
    }

    function isRisuPayload(card, avatar = '') {
        const risuData = getRisuData(card);
        const scopedRegex = card?.data?.extensions?.regex_scripts || card?.extensions?.regex_scripts;
        return Boolean(
            avatar.endsWith('.charx')
            || (Array.isArray(scopedRegex) && scopedRegex.length > 0)
            || risuData?.charxImported
            || risuData?.charxModule
            || risuData?.backgroundHTML
        );
    }

    function getAssetOwner(card, avatar = '') {
        const risuData = getRisuData(card);
        return risuData?.charxFile || risuData?.assetRoot || avatar || sanitizeName(getCardData(card)?.name);
    }

    function getCardAssets(card) {
        const directAssets = Array.isArray(getCardData(card)?.assets) ? getCardData(card).assets : [];
        if (directAssets.length > 0) {
            return directAssets;
        }

        const risuData = getRisuData(card) || {};
        const cardData = getCardData(card);
        const candidates = [...new Set([
            String(risuData?.charxFile || '').trim(),
            pathFromName(risuData?.charxFile),
            String(risuData?.assetRoot || '').trim(),
            pathFromName(risuData?.assetRoot),
            String(card?.avatar || '').trim(),
            pathFromName(card?.avatar),
            String(cardData?.avatar || '').trim(),
            pathFromName(cardData?.avatar),
            String(cardData?.name || card?.name || '').trim(),
            pathFromName(cardData?.name || card?.name),
        ].filter(Boolean))];

        for (const candidate of candidates) {
            const cached = metadataCache.get(candidate);
            const cachedAssets = Array.isArray(cached?.data?.assets) ? cached.data.assets : [];
            if (cachedAssets.length > 0) {
                return cachedAssets;
            }
        }

        return [];
    }

    function normalizeAssetLookupKey(value) {
        return String(value || '')
            .normalize('NFKD')
            .trim()
            .replace(/^['"]|['"]$/g, '')
            .replace(/[\u2018\u2019\u02BC\uFF07`´']/g, '')
            .replace(/\.(png|jpe?g|webp|gif|apng|avif|bmp|jfif)$/i, '')
            .toLowerCase()
            .replace(/[.\s-]+/g, '_')
            .replace(/_+/g, '_')
            .replace(/^_+|_+$/g, '');
    }

    function getAssetLookupMatchScore(desiredLower, desiredNormalized, candidate) {
        const rawCandidate = String(candidate || '').toLowerCase();
        const normalizedCandidate = normalizeAssetLookupKey(candidate);
        if (rawCandidate === desiredLower || normalizedCandidate === desiredNormalized) {
            return 3;
        }

        if (desiredNormalized && (normalizedCandidate.endsWith(`_${desiredNormalized}`) || normalizedCandidate.startsWith(`${desiredNormalized}_`))) {
            return 1;
        }

        return 0;
    }

    function resolveCardAssetPath(card, assetName) {
        const desired = String(assetName || '').trim().replace(/^['"]|['"]$/g, '');
        if (!desired) {
            return '';
        }

        const assets = getCardAssets(card);
        const desiredLower = desired.toLowerCase();
        const desiredNormalized = normalizeAssetLookupKey(desired);

        let matched = null;
        let bestScore = 0;

        for (const asset of assets) {
            const name = String(asset?.name || '').trim();
            const ext = String(asset?.ext || '').trim();
            const nameBase = name ? name.replace(/\.[^.]+$/, '') : '';
            const uri = String(asset?.uri || '').replace(/^embeded:\/\//i, '');
            const uriBase = uri ? uri.split('/').pop() : '';
            const uriBaseNoExt = uriBase ? uriBase.replace(/\.[^.]+$/, '') : '';
            const nameWithExt = name && ext && !name.toLowerCase().endsWith(`.${ext.toLowerCase()}`)
                ? `${name}.${ext}`
                : '';

            const score = Math.max(...[name, nameBase, nameWithExt, uri, uriBase, uriBaseNoExt]
                .filter(Boolean)
                .map((candidate) => getAssetLookupMatchScore(desiredLower, desiredNormalized, candidate)), 0);

            if (score > bestScore) {
                bestScore = score;
                matched = asset;
                if (score >= 3) {
                    break;
                }
            }
        }

        if (!matched?.uri) {
            return desired;
        }

        return String(matched.uri).replace(/^embeded:\/\//i, '') || desired;
    }

    function buildAssetUrl(assetOwner, assetName, card = null) {
        const owner = String(assetOwner || '').trim();
        const asset = resolveCardAssetPath(card, assetName);

        if (!owner || !asset) {
            return '';
        }

        return `${assetBaseUrl}?name=${encodeURIComponent(owner)}&assetPath=${encodeURIComponent(asset)}`;
    }

    function makeImgTag(assetOwner, assetName, card = null) {
        const cleanName = String(assetName || '').trim().replace(/^['"]|['"]$/g, '');
        const url = buildAssetUrl(assetOwner, cleanName, card);

        if (!url) {
            return '';
        }

        return `<img src="${url}" style="max-width:100%; border-radius:10px; margin:10px 0; display:block; cursor:pointer;" onclick="event.stopPropagation(); window.open(this.src, '_blank');" title="${cleanName}">`;
    }

    function getAssetList(card) {
        const assets = getCardAssets(card);
        const values = [];

        for (const asset of assets) {
            if (asset?.name) {
                values.push(String(asset.name));
                if (asset.ext) {
                    values.push(`${asset.name}.${asset.ext}`);
                }
            }

            if (asset?.uri) {
                const fileName = String(asset.uri).split('/').pop();
                if (fileName) {
                    values.push(fileName);
                    values.push(fileName.replace(/\.[^.]+$/, ''));
                }
            }
        }

        return [...new Set(values.filter(Boolean))];
    }

    function getRisuPortraitAssets(card) {
        const assets = getCardAssets(card);
        const imageExts = new Set(['png', 'jpg', 'jpeg', 'webp', 'gif', 'apng', 'avif', 'bmp', 'jfif']);
        const iconAssets = assets
            .filter((asset) => {
                const type = String(asset?.type || '').toLowerCase();
                const ext = String(asset?.ext || '').toLowerCase();
                const uri = String(asset?.uri || '').trim();
                return ['icon', 'user_icon'].includes(type)
                    && uri
                    && (imageExts.has(ext) || /\.(png|jpe?g|webp|gif|apng|avif|bmp|jfif)$/i.test(uri));
            })
            .map((asset, index) => {
                const assetPath = String(asset?.uri || '').replace(/^embeded:\/\//i, '').trim();
                const fileName = assetPath.split('/').pop() || '';
                const fileBase = fileName.replace(/\.[^.]+$/, '');
                const rawName = String(asset?.name || '').trim();
                const lowerName = rawName.toLowerCase();
                return {
                    index,
                    rawName,
                    lowerName,
                    assetPath,
                    label: rawName || fileBase || `portrait-${index + 1}`,
                };
            })
            .filter((asset) => asset.assetPath);

        if (!iconAssets.length) {
            return [];
        }

        const uniqueAssets = [];
        const seen = new Set();
        for (const asset of iconAssets) {
            if (seen.has(asset.assetPath)) {
                continue;
            }
            seen.add(asset.assetPath);
            uniqueAssets.push(asset);
        }

        uniqueAssets.sort((left, right) => {
            const leftIsMain = left.lowerName === 'main' || /(?:^|\/)main\.[^.]+$/i.test(left.assetPath);
            const rightIsMain = right.lowerName === 'main' || /(?:^|\/)main\.[^.]+$/i.test(right.assetPath);
            if (leftIsMain !== rightIsMain) {
                return leftIsMain ? -1 : 1;
            }
            return left.index - right.index;
        });

        return uniqueAssets;
    }

    function parseDefaultVariables(value) {
        const result = {};
        if (typeof value !== 'string' || !value.trim()) {
            return result;
        }

        try {
            const parsed = JSON.parse(value);
            if (parsed && typeof parsed === 'object') {
                for (const [key, entryValue] of Object.entries(parsed)) {
                    result[key] = String(entryValue);
                }
                return result;
            }
        } catch {
            // Fall through.
        }

        for (const line of value.split(/\r?\n/)) {
            const trimmed = line.trim();
            if (!trimmed) {
                continue;
            }

            const separatorIndex = trimmed.search(/[:=]/);
            if (separatorIndex === -1) {
                continue;
            }

            const key = trimmed.slice(0, separatorIndex).trim();
            const entryValue = trimmed.slice(separatorIndex + 1).trim();
            if (key) {
                result[key] = entryValue;
            }
        }

        return result;
    }

    function splitRisuLorebookKeys(value) {
        if (Array.isArray(value)) {
            return value.map(x => String(x).trim()).filter(Boolean);
        }

        if (typeof value !== 'string') {
            return [];
        }

        return value
            .split(/\r?\n|[,|]/)
            .map(x => x.trim())
            .filter(Boolean);
    }

    function mergeModuleLorebook(characterData, module) {
        const lorebook = Array.isArray(module?.lorebook) ? module.lorebook : [];
        if (!characterData || lorebook.length === 0) {
            return;
        }

        const existingBook = characterData.character_book || {};
        const existingEntries = Array.isArray(existingBook.entries) ? [...existingBook.entries] : [];
        let nextId = existingEntries.reduce((maxId, entry) => Math.max(maxId, Number(entry?.id) || 0), 0) + 1;

        for (const entry of lorebook) {
            if (!entry || typeof entry.content !== 'string' || !entry.content.trim()) {
                continue;
            }

            existingEntries.push({
                keys: splitRisuLorebookKeys(entry.key),
                content: entry.content,
                enabled: true,
                insertion_order: Number.isFinite(Number(entry.insertorder)) ? Number(entry.insertorder) : 100,
                case_sensitive: false,
                priority: 10,
                use_regex: Boolean(entry.useRegex),
                name: entry.comment || '',
                id: nextId++,
                comment: entry.comment || '',
                selective: Boolean(entry.selective),
                secondary_keys: splitRisuLorebookKeys(entry.secondkey),
                constant: Boolean(entry.alwaysActive),
                position: 'before_char',
                extensions: entry.bookVersion ? { risuai: { bookVersion: entry.bookVersion, mode: entry.mode || 'normal' } } : {},
            });
        }

        characterData.character_book = {
            scan_depth: existingBook.scan_depth ?? 100,
            token_budget: existingBook.token_budget ?? 512,
            recursive_scanning: existingBook.recursive_scanning ?? false,
            entries: existingEntries,
            extensions: existingBook.extensions || {},
        };
    }

    function normalizeRegexPattern(pattern) {
        let normalized = String(pattern || '').trim();
        if (!normalized) {
            return '';
        }

        normalized = normalized.replace(/\{\{:else\}\}/g, '|');
        normalized = normalized.replace(/\{\{#(?:if|when)[\s\S]*?\}\}/g, '');
        normalized = normalized.replace(/\{\{\/(?:if|when)?\}\}/g, '');
        normalized = normalized.replace(/\{\{\/\}\}/g, '');
        normalized = normalized.trim();

        if (normalized.length % 2 === 0) {
            const half = normalized.length / 2;
            if (normalized.slice(0, half) === normalized.slice(half)) {
                normalized = normalized.slice(0, half);
            }
        }

        if (normalized && !normalized.startsWith('/')) {
            normalized = `/${normalized}/gi`;
        }

        return normalized;
    }

    function getRegexMapping(rule) {
        const type = String(rule?.type || '').toLowerCase();
        const isDisplay = type === 'editdisplay' || type.includes('display') || rule?.editdisplay === true;
        const isProcess = type === 'editprocess' || type.includes('process') || type.includes('request');
        const isInput = type === 'editinput' || type.includes('input');

        if (isInput) {
            return {
                placement: [REGEX_PLACEMENT.USER_INPUT],
                markdownOnly: false,
                promptOnly: false,
            };
        }

        if (isProcess) {
            return {
                // Risu "Modify Request Data" acts on chat content at send time.
                // In ST, the closest equivalent is a prompt-only transform on the
                // affected message side rather than a display-only rule.
                placement: [REGEX_PLACEMENT.AI_OUTPUT],
                markdownOnly: false,
                promptOnly: true,
            };
        }

        return {
            placement: [REGEX_PLACEMENT.AI_OUTPUT],
            markdownOnly: isDisplay,
            promptOnly: false,
        };
    }

    function shouldDisableRisuScopedScript(rule, mapping) {
        const type = String(rule?.type || '').toLowerCase();
        return type === 'editdisplay' || mapping?.markdownOnly === true;
    }

    function mapRisuRegexScripts(module) {
        const regexRules = Array.isArray(module?.regex) ? module.regex : [];

        return regexRules.map((rule, index) => {
            const mapping = getRegexMapping(rule);
            const type = String(rule?.type || '').toLowerCase();
            return {
                id: rule.id || `risu-regex-${index}`,
                scriptName: rule.comment || rule.type || `Risu Regex ${index}`,
                findRegex: normalizeRegexPattern(rule.in),
                replaceString: String(rule.out || ''),
                trimStrings: [],
                placement: mapping.placement,
                disabled: type === 'disabled' || rule?.disabled === true || shouldDisableRisuScopedScript(rule, mapping),
                markdownOnly: mapping.markdownOnly,
                promptOnly: mapping.promptOnly,
                runOnEdit: mapping.markdownOnly,
                substituteRegex: 0,
                minDepth: null,
                maxDepth: null,
                risuCompat: true,
                source: 'risuai',
                risuRuleType: type,
            };
        }).filter(script => script.findRegex);
    }

    function getRisuScriptSignature(script) {
        if (!script || typeof script !== 'object') {
            return '';
        }

        const name = String(script.scriptName || '').trim();
        const findRegex = String(script.findRegex || '').trim();
        if (!name || !findRegex) {
            return '';
        }

        return `${name}::${normalizeRegexPattern(findRegex)}`;
    }

    function matchesMappedRisuScript(existing, mapped) {
        if (!existing || !mapped) {
            return false;
        }

        const existingId = String(existing.id || '').trim();
        const mappedId = String(mapped.id || '').trim();
        if (existingId && mappedId && existingId === mappedId) {
            return true;
        }

        const existingSignature = getRisuScriptSignature(existing);
        const mappedSignature = getRisuScriptSignature(mapped);
        if (existingSignature && mappedSignature && existingSignature === mappedSignature) {
            return true;
        }

        const existingName = String(existing.scriptName || '').trim();
        const mappedName = String(mapped.scriptName || '').trim();
        if (!existingName || !mappedName || existingName !== mappedName) {
            return false;
        }

        const existingFind = normalizeRegexPattern(String(existing.findRegex || '').trim());
        const mappedFind = normalizeRegexPattern(String(mapped.findRegex || '').trim());
        if (existingFind && mappedFind && existingFind === mappedFind) {
            return true;
        }

        const existingRuleType = String(existing.risuRuleType || '').trim().toLowerCase();
        const mappedRuleType = String(mapped.risuRuleType || '').trim().toLowerCase();
        return Boolean(existingRuleType && mappedRuleType && existingRuleType === mappedRuleType);
    }

    function mergeMappedRisuRegexScripts(existingScripts, mappedScripts) {
        const existingList = Array.isArray(existingScripts) ? existingScripts : [];

        return mappedScripts.map((script) => {
            const existing = existingList.find(existingScript => matchesMappedRisuScript(existingScript, script));
            if (!existing) {
                return script;
            }

            return {
                ...script,
                disabled: typeof existing.disabled === 'boolean' ? existing.disabled : script.disabled,
            };
        });
    }

    function getRisuProcessRegexRules(card) {
        const rules = Array.isArray(getRisuModule(card)?.regex) ? getRisuModule(card).regex : [];
        return rules.filter((rule) => !rule?.disabled && String(rule?.type || '').toLowerCase() === 'editprocess' && String(rule?.in || '').trim());
    }

    function getRisuOutputRegexRules(card) {
        const rules = Array.isArray(getRisuModule(card)?.regex) ? getRisuModule(card).regex : [];
        return rules.filter((rule) => !rule?.disabled && String(rule?.type || '').toLowerCase() === 'editoutput' && String(rule?.in || '').trim());
    }

    function getRisuDisplayRegexRules(card) {
        const rules = Array.isArray(getRisuModule(card)?.regex) ? getRisuModule(card).regex : [];
        return rules.filter((rule) => !rule?.disabled && String(rule?.type || '').toLowerCase() === 'editdisplay' && String(rule?.in || '').trim());
    }

    function parseRegexLiteral(findRegex) {
        const value = String(findRegex || '').trim();
        if (!value) {
            return null;
        }

        if (!value.startsWith('/')) {
            try {
                return new RegExp(value, 'g');
            } catch {
                return null;
            }
        }

        const lastSlashIndex = value.lastIndexOf('/');
        if (lastSlashIndex <= 0) {
            return null;
        }

        const pattern = value.slice(1, lastSlashIndex);
        const flags = value.slice(lastSlashIndex + 1) || 'g';
        try {
            return new RegExp(pattern, flags);
        } catch {
            return null;
        }
    }

    function applyRisuRegexRules(text, env, rules, options = {}) {
        let output = renderRisuTemplate(restoreRisuTemplateText(text), env, { convertAssetTags: false, ...options });
        output = String(output || '').replace(/\r\n?/g, '\n');
        if (!rules.length) {
            return output;
        }

        for (const rule of rules) {
            const regex = parseRegexLiteral(normalizeRegexPattern(rule.in));
            if (!regex) {
                continue;
            }

            if (!regex.test(output)) {
                continue;
            }

            regex.lastIndex = 0;
            output = output.replace(regex, String(rule.out || ''));
            output = renderRisuTemplate(output, env, { convertAssetTags: false, ...options });
            output = String(output || '').replace(/\r\n?/g, '\n');
        }

        return output;
    }

    function applyRisuProcessScripts(text, env) {
        return applyRisuRegexRules(text, env, getRisuProcessRegexRules(env?.descriptor?.character));
    }

    function applyRisuOutputScripts(text, env) {
        return applyRisuRegexRules(text, env, getRisuOutputRegexRules(env?.descriptor?.character), { renderComments: true });
    }

    function applyRisuDisplayScripts(text, env) {
        return applyRisuRegexRules(text, env, getRisuDisplayRegexRules(env?.descriptor?.character), { renderComments: true });
    }

    async function getRisuCharacters() {
        try {
            const response = await fetch('/api/plugins/risuai-importer/list');
            return response.ok ? await response.json() : [];
        } catch {
            return [];
        }
    }

    async function getRisuMetadata(filename, fallbackName = '') {
        const candidates = [...new Set([
            String(filename || '').trim(),
            pathFromName(filename),
            String(fallbackName || '').trim(),
            pathFromName(fallbackName),
        ].filter(Boolean))];

        for (const candidate of candidates) {
            if (metadataCache.has(candidate)) {
                const cached = metadataCache.get(candidate);
                if (cached) {
                    return cached;
                }
                continue;
            }

            try {
                const response = await fetch(`/api/plugins/risuai-importer/get-metadata?name=${encodeURIComponent(candidate)}`);
                if (!response.ok) {
                    metadataCache.set(candidate, null);
                    continue;
                }

                const metadata = await response.json();
                metadataCache.set(candidate, metadata);
                return metadata;
            } catch {
                metadataCache.set(candidate, null);
            }
        }

        return null;
    }

    function pathFromName(value) {
        const stringValue = String(value || '').trim();
        if (!stringValue) {
            return '';
        }

        return stringValue.replace(/\.[^.]+$/, '');
    }

    async function ensureScopedRegexAllowed(avatar) {
        const runtime = await runtimePromise;
        if (!runtime || !avatar) {
            return false;
        }

        const { extension_settings } = runtime.extensionsApi;
        const { saveSettingsDebounced } = runtime.scriptApi;

        if (!Array.isArray(extension_settings.character_allowed_regex)) {
            extension_settings.character_allowed_regex = [];
        }

        if (!extension_settings.character_allowed_regex.includes(avatar)) {
            extension_settings.character_allowed_regex.push(avatar);
            saveSettingsDebounced();
            return true;
        }

        return false;
    }

    async function activateScopedRegex(avatar) {
        const runtime = await runtimePromise;
        if (!runtime || !avatar) {
            return;
        }

        const added = await ensureScopedRegexAllowed(avatar);
        if (!added || regexReloadScheduled) {
            if (regexReloadScheduled) {
                return;
            }
        }

        const { eventSource, event_types, getCurrentChatId, reloadCurrentChat } = runtime.scriptApi;

        regexReloadScheduled = true;
        setTimeout(async () => {
            try {
                if (eventSource?.emit && event_types?.CHAT_CHANGED) {
                    await eventSource.emit(event_types.CHAT_CHANGED, typeof getCurrentChatId === 'function' ? getCurrentChatId() : null);
                }

                if (added && typeof getCurrentChatId === 'function' && typeof reloadCurrentChat === 'function' && getCurrentChatId()) {
                    await reloadCurrentChat();
                }
            } catch (error) {
                console.warn('[RisuAI Importer] Failed to reload chat after enabling scoped regex', error);
            } finally {
                regexReloadScheduled = false;
            }
        }, 150);
    }

    function augmentRisuCharacterPayload(payload, avatar, cardDataOverride = null, moduleOverride = null) {
        const processed = getStructuredClone(payload);
        const risuData = getRisuData(processed) || {};
        const module = moduleOverride || risuData.charxModule || null;

        if (cardDataOverride && processed.data) {
            processed.data = { ...cardDataOverride };
        } else if (cardDataOverride) {
            Object.assign(processed, cardDataOverride);
        }

        const mutableData = processed.data || processed;
        mutableData.extensions = mutableData.extensions || {};
        mutableData.extensions.risuai = mutableData.extensions.risuai || {};

        processed.first_mes = protectRisuTemplateText(processed.first_mes);
        mutableData.first_mes = protectRisuTemplateText(mutableData.first_mes);
        processed.alternate_greetings = protectRisuGreetingList(processed.alternate_greetings);
        mutableData.alternate_greetings = protectRisuGreetingList(mutableData.alternate_greetings);

        if (module?.background_embedding && !mutableData.extensions.risuai.backgroundHTML) {
            mutableData.extensions.risuai.backgroundHTML = module.background_embedding;
        }

        mutableData.extensions.risuai.charxFile = mutableData.extensions.risuai.charxFile || risuData.charxFile || '';
        mutableData.extensions.risuai.assetRoot = mutableData.extensions.risuai.assetRoot || getAssetOwner(processed, avatar);

        if (module) {
            mutableData.extensions.risuai.charxModule = module;
            mergeModuleLorebook(mutableData, module);
        }

        const existingScopedRegex = Array.isArray(mutableData.extensions.regex_scripts)
            ? mutableData.extensions.regex_scripts
            : [];
        const mappedRegex = mergeMappedRisuRegexScripts(existingScopedRegex, mapRisuRegexScripts(module));
        if (mappedRegex.length > 0) {
            mutableData.extensions.regex_scripts = existingScopedRegex
                .filter(script => !mappedRegex.some(mappedScript => matchesMappedRisuScript(script, mappedScript)));
            mutableData.extensions.regex_scripts.push(...mappedRegex);
        }

        mutableData.extensions.regex_scripts = protectRisuRegexScripts(mutableData.extensions.regex_scripts);
        mutableData.extensions.regex_scripts = disableManagedRisuScopedScripts(mutableData.extensions.regex_scripts);

        if (Array.isArray(mutableData.extensions.regex_scripts) && mutableData.extensions.regex_scripts.length > 0) {
            setTimeout(() => activateScopedRegex(avatar), 0);
        }

        return processed;
    }

    async function recoverRisuMetadata(payload, avatar) {
        const mutableData = payload?.data || payload || {};
        const risuData = getRisuData(payload);
        const charxFile = String(risuData?.charxFile || '').trim();

        if (avatar.endsWith('.charx')) {
            return null;
        }

        if (charxFile) {
            return await getRisuMetadata(charxFile, avatar || mutableData?.name || payload?.name || '');
        }

        if (risuData?.charxModule && !risuData?.charxImported) {
            return null;
        }

        const cardName = getCardData(payload)?.name || payload?.name || '';
        return await getRisuMetadata(avatar, cardName);
    }

    function ensureActiveCharacterRegexAllowed() {
        const character = getActiveCharacter();
        const avatar = character?.avatar || '';
        const scopedRegex = character?.data?.extensions?.regex_scripts;

        if (!avatar || !Array.isArray(scopedRegex) || scopedRegex.length === 0) {
            return;
        }

        activateScopedRegex(avatar);
    }

    function getActiveCharacter() {
        const context = getContext();
        if (!context || context.characterId === undefined || !runtimeApi?.scriptApi?.characters) {
            return null;
        }

        return runtimeApi.scriptApi.characters[context.characterId] || null;
    }

    function getActiveRisuDescriptor() {
        const character = getActiveCharacter();
        if (!character || !isRisuPayload(character, character.avatar || '')) {
            return null;
        }

        seedRisuVariablesFromTriggers(character);

        const risuData = getRisuData(character) || {};
        return {
            character,
            avatar: character.avatar || '',
            assetOwner: getAssetOwner(character, character.avatar || ''),
            assetList: getAssetList(character),
            portraitAssets: getRisuPortraitAssets(character),
            defaultVariables: parseDefaultVariables(risuData.defaultVariables),
            isLargePortrait: risuData.largePortrait === true,
        };
    }

    async function getResolvedRisuCardData(descriptor) {
        const character = descriptor?.character;
        if (!character) {
            return null;
        }

        const cacheKey = character.avatar || character.name || '';
        if (cacheKey && resolvedCardDataCache.has(cacheKey)) {
            return resolvedCardDataCache.get(cacheKey);
        }

        const primaryCardData = getCardData(character);
        const primaryFirstMes = String(character?.first_mes || primaryCardData?.first_mes || '');
        const primaryAlternateGreetings = [
            ...(Array.isArray(character?.alternate_greetings) ? character.alternate_greetings : []),
            ...(Array.isArray(primaryCardData?.alternate_greetings) ? primaryCardData.alternate_greetings : []),
        ];

        if (primaryFirstMes.trim() || primaryAlternateGreetings.length > 0) {
            if (cacheKey) resolvedCardDataCache.set(cacheKey, primaryCardData);
            return primaryCardData;
        }

        const metadata = await recoverRisuMetadata(character, character.avatar || '');
        const metadataCard = metadata?.card || metadata?.data || metadata || null;
        const metadataCardData = metadataCard?.data || metadataCard;
        if (metadataCardData && (String(metadataCard?.first_mes || metadataCardData?.first_mes || '').trim()
            || Array.isArray(metadataCard?.alternate_greetings)
            || Array.isArray(metadataCardData?.alternate_greetings))) {
            if (cacheKey) resolvedCardDataCache.set(cacheKey, metadataCardData);
            return metadataCardData;
        }

        if (cacheKey) resolvedCardDataCache.set(cacheKey, primaryCardData);
        return primaryCardData;
    }

    function getRisuPortraitStateKey(descriptor) {
        return String(descriptor?.assetOwner || descriptor?.avatar || descriptor?.character?.name || '').trim();
    }

    function getSelectedRisuPortraitIndex(descriptor) {
        const portraits = Array.isArray(descriptor?.portraitAssets) ? descriptor.portraitAssets : [];
        if (!portraits.length) {
            return -1;
        }

        const key = getRisuPortraitStateKey(descriptor);
        const rawIndex = Number(risuPortraitSelection.get(key));
        if (!Number.isFinite(rawIndex) || rawIndex < 0) {
            return 0;
        }

        return Math.min(rawIndex, portraits.length - 1);
    }

    function getSelectedRisuPortrait(descriptor) {
        const portraits = Array.isArray(descriptor?.portraitAssets) ? descriptor.portraitAssets : [];
        const index = getSelectedRisuPortraitIndex(descriptor);
        return index >= 0 ? portraits[index] || null : null;
    }

    function setSelectedRisuPortraitIndex(descriptor, index) {
        const portraits = Array.isArray(descriptor?.portraitAssets) ? descriptor.portraitAssets : [];
        if (!portraits.length) {
            return;
        }

        const maxIndex = portraits.length - 1;
        const normalizedIndex = ((Number(index) % portraits.length) + portraits.length) % portraits.length;
        const clampedIndex = Math.min(Math.max(normalizedIndex, 0), maxIndex);
        const key = getRisuPortraitStateKey(descriptor);
        if (!key) {
            return;
        }

        risuPortraitSelection.set(key, clampedIndex);
    }

    function getSelectedRisuPortraitUrl(descriptor) {
        const portrait = getSelectedRisuPortrait(descriptor);
        if (!portrait?.assetPath) {
            return `${avatarBaseUrl}?name=${encodeURIComponent(descriptor?.assetOwner || descriptor?.avatar || '')}`;
        }

        return buildAssetUrl(descriptor?.assetOwner || descriptor?.avatar || '', portrait.assetPath, descriptor?.character);
    }

    function createRisuEnv(descriptor, messageId = -1) {
        const context = getContext();
        return {
            descriptor,
            assetOwner: descriptor.assetOwner,
            assetList: descriptor.assetList,
            variables: {
                first: '1',
                lang: 'en',
                user_role: 'student',
                emotional_level: '0',
                ...descriptor.defaultVariables,
                ...window.risu_context.globalVariables,
                ...window.risu_context.variables,
            },
            globalVariables: window.risu_context.globalVariables,
            temp: {},
            slots: {},
            messageId,
            chatIndex: messageId,
            lastMessageId: Array.isArray(runtimeApi?.scriptApi?.chat) && runtimeApi.scriptApi.chat.length > 0
                ? runtimeApi.scriptApi.chat.length - 1
                : messageId,
            userName: context?.name1 || 'User',
            charName: context?.name2 || descriptor.character?.name || 'Character',
        };
    }

    function getFirstCharacterMessageId(chat) {
        if (!Array.isArray(chat)) {
            return -1;
        }

        for (let index = 0; index < chat.length; index++) {
            const message = chat[index];
            const hasMessageShape = Boolean(message)
                && (
                    typeof message?.mes === 'string'
                    || Array.isArray(message?.swipes)
                    || typeof message?.send_date === 'string'
                    || typeof message?.is_user === 'boolean'
                    || typeof message?.is_system === 'boolean'
                );

            if (!hasMessageShape || message.is_system || message.is_user || message?.extra?.type === 'narrator') {
                continue;
            }

            if (typeof message?.mes === 'string' || Array.isArray(message?.swipes)) {
                return index;
            }
        }

        return -1;
    }

    function getManualRisuTriggers(card) {
        const triggers = Array.isArray(getRisuModule(card)?.trigger) ? getRisuModule(card).trigger : [];
        return triggers.filter(trigger => trigger?.type === 'manual' && Array.isArray(trigger?.effect));
    }

    function applyRisuTriggerEffects(effects, targetVariables) {
        if (!Array.isArray(effects) || !targetVariables) {
            return false;
        }

        let changed = false;
        for (const effect of effects) {
            if (!effect || effect.type !== 'v2SetVar' || !effect.var) {
                continue;
            }

            const value = effect.valueType === 'value'
                ? String(effect.value ?? '')
                : String(targetVariables[effect.value] ?? '');

            if (effect.operator && effect.operator !== '=') {
                continue;
            }

            if (targetVariables[effect.var] !== value) {
                targetVariables[effect.var] = value;
                changed = true;
            }
        }

        return changed;
    }

    function seedRisuVariablesFromTriggers(card) {
        const avatar = card?.avatar || '';
        const variables = window.risu_context.variables = window.risu_context.variables || {};
        const triggerSeedKey = `__risu_seeded__${avatar}`;
        if (variables[triggerSeedKey] === '1') {
            return;
        }

        const triggers = getManualRisuTriggers(card);
        if (triggers.length === 0) {
            return;
        }

        const findTrigger = (name) => triggers.find(trigger => String(trigger.comment || '') === name);
        const applyIfMissing = (name, watchedKeys) => {
            if (!watchedKeys.some((key) => variables[key] === undefined || variables[key] === null || variables[key] === '')) {
                return;
            }

            const trigger = findTrigger(name);
            if (trigger) {
                applyRisuTriggerEffects(trigger.effect, variables);
            }
        };

        applyIfMissing('resetStartScreen', ['cv_started', 'cv_scenario']);
        applyIfMissing('setLangEn', ['cv_lang']);
        applyIfMissing('secretClose', ['cv_secret']);
        applyIfMissing('setOptAssetOff', ['cv_opt_asset']);
        applyIfMissing('setOptNsfwOff', ['cv_opt_nsfw']);
        applyIfMissing('setOptStatuswindowOff', ['cv_opt_statuswindow']);
        applyIfMissing('setOptEstherOff', ['cv_opt_esther']);
        applyIfMissing('setOptExtraOff', ['cv_opt_extra']);

        variables[triggerSeedKey] = '1';
    }

    function valueToString(value) {
        if (value === null || value === undefined) return '';
        if (Array.isArray(value)) return value.join(',');
        if (typeof value === 'boolean') return value ? '1' : '0';
        return String(value);
    }

    function parseRisuArrayValue(value) {
        if (Array.isArray(value)) {
            return value;
        }

        const stringValue = typeof value === 'string' ? value.trim() : '';
        if (!stringValue) {
            return null;
        }

        try {
            const parsed = JSON.parse(stringValue);
            return Array.isArray(parsed) ? parsed : null;
        } catch {
            return null;
        }
    }

    function parseRisuListLikeValue(value) {
        if (Array.isArray(value)) {
            return value.map((entry) => valueToString(entry));
        }

        const parsedArray = parseRisuArrayValue(value);
        if (parsedArray) {
            return parsedArray.map((entry) => valueToString(entry));
        }

        const stringValue = valueToString(value);
        return stringValue ? [stringValue] : [];
    }

    function isTruthyRisuValue(value) {
        const normalized = valueToString(value).trim().toLowerCase();
        return normalized !== '' && normalized !== '0' && normalized !== 'false' && normalized !== 'null' && normalized !== 'undefined';
    }

    function splitTopLevelByDoubleColon(text) {
        const parts = [];
        let current = '';
        let depth = 0;

        for (let index = 0; index < text.length; index++) {
            const pair = text.slice(index, index + 2);

            if (pair === '{{') {
                depth++;
                current += pair;
                index++;
                continue;
            }

            if (pair === '}}' && depth > 0) {
                depth--;
                current += pair;
                index++;
                continue;
            }

            if (pair === '::' && depth === 0) {
                parts.push(current);
                current = '';
                index++;
                continue;
            }

            current += text[index];
        }

        parts.push(current);
        return parts;
    }

    function findTagEnd(text, startIndex) {
        let depth = 0;

        for (let index = startIndex; index < text.length - 1; index++) {
            const pair = text.slice(index, index + 2);
            if (pair === '{{') {
                depth++;
                index++;
                continue;
            }

            if (pair === '}}') {
                depth--;
                index++;
                if (depth === 0) {
                    return index + 1;
                }
            }
        }

        return -1;
    }

    function getTagType(tagContent) {
        if (tagContent.startsWith('#if')) return { kind: 'open', block: 'if' };
        if (tagContent.startsWith('#when')) return { kind: 'open', block: 'when' };
        if (tagContent.startsWith('#each')) return { kind: 'open', block: 'each' };
        if (tagContent === ':else') return { kind: 'else' };
        if (tagContent === '/' || tagContent === '/if') return { kind: 'close', block: 'if' };
        if (tagContent === '/when') return { kind: 'close', block: 'when' };
        if (tagContent === '/each') return { kind: 'close', block: 'each' };
        return { kind: 'simple' };
    }

    function findBlockBounds(text, openStart, blockName) {
        const openEnd = findTagEnd(text, openStart);
        if (openEnd === -1) return null;

        let cursor = openEnd;
        const stack = [];
        let elseStart = -1;
        let elseEnd = -1;

        while (cursor < text.length) {
            const tagStart = text.indexOf('{{', cursor);
            if (tagStart === -1) break;

            const tagEnd = findTagEnd(text, tagStart);
            if (tagEnd === -1) break;

            const tagContent = text.slice(tagStart + 2, tagEnd - 2).trim();
            const tagType = getTagType(tagContent);

            if (tagType.kind === 'open') {
                stack.push(tagType.block);
            } else if (tagType.kind === 'close') {
                if (stack.length > 0) {
                    stack.pop();
                } else if (tagContent === '/' || tagType.block === blockName) {
                    return { openEnd, closeStart: tagStart, closeEnd: tagEnd, elseStart, elseEnd };
                }
            } else if (tagType.kind === 'else' && stack.length === 0) {
                elseStart = tagStart;
                elseEnd = tagEnd;
            }

            cursor = tagEnd;
        }

        return null;
    }

    function renderSimpleContent(content, env, options = {}) {
        if (typeof content !== 'string' || !content.includes('{{')) {
            return content;
        }

        return renderRisuTemplate(content, env, { ...options, allowBlocks: false });
    }

    function renderRisuArgumentContent(content, env, options = {}) {
        if (typeof content !== 'string' || !content.includes('{{')) {
            return content;
        }

        return renderRisuTemplate(content, env, { ...options, convertAssetTags: false });
    }

    function evaluateSimpleTag(rawTag, env, options = {}) {
        const content = rawTag.slice(2, -2).trim();

        if (content.startsWith('?')) {
            const expr = renderSimpleContent(content.slice(1).trim(), env, options);
            try {
                const result = new Function(`return (${expr});`)();
                return result ? '1' : '0';
            } catch {
                return '0';
            }
        }

        if (/^comment\s*:/i.test(content)) {
            if (options.renderComments !== true) {
                return '';
            }

            const commentSource = content.replace(/^comment\s*:/i, '').trim();
            if (!commentSource) {
                return '';
            }

            let commentHtml = String(renderRisuTemplate(commentSource, env, {
                ...options,
                renderComments: false,
                convertAssetTags: false,
            }) || '');

            // Song Sisters uses a comment block whose italic body is a hidden
            // copy/paste payload. Risu shows only the note line, not the
            // literal {{roll:...}} payload.
            if (/\{\{\s*roll\s*:[^}]+\}\}/i.test(commentHtml) && /<i\b[\s\S]*?<\/i>/i.test(commentHtml)) {
                commentHtml = commentHtml
                    .replace(/\s*<br\s*\/?>\s*<i\b[\s\S]*?<\/i>\s*/i, '')
                    .replace(/\s*<i\b[\s\S]*?<\/i>\s*/i, '');
            }

            const formattedCommentHtml = commentHtml.replace(
                /\{\{[\s\S]*?\}\}/g,
                (match) => `<code class="risu-comment-inline-code">${match}</code>`,
            );
            return formattedCommentHtml;
        }

        const parts = splitTopLevelByDoubleColon(content).map(part => part.trim());
        const command = parts[0];
        const normalizedCommand = String(command || '').toLowerCase();
        const args = parts.slice(1).map(arg => renderRisuArgumentContent(arg, env, options));

        switch (normalizedCommand) {
            case 'user':
                return env.userName;
            case 'char':
                return env.charName;
            case 'ddecbo':
                return '{{';
            case 'ddecbc':
                return '}}';
            case 'screen_width':
                return String(window.innerWidth);
            case 'screen_height':
                return String(window.innerHeight);
            case 'assetlist':
                return env.assetList;
            case 'slot':
                return env.slots[args[0]] ?? '';
            case 'getvar':
                return env.variables[args[0]] ?? '';
            case 'getglobalvar':
            case 'getvar_global':
                return env.globalVariables?.[args[0]] ?? '';
            case 'setvar':
                env.variables[args[0]] = valueToString(args[1]);
                window.risu_context.variables[args[0]] = valueToString(args[1]);
                return '';
            case 'setdefaultvar':
                if (!env.variables[args[0]]) {
                    env.variables[args[0]] = valueToString(args[1]);
                    window.risu_context.variables[args[0]] = valueToString(args[1]);
                }
                return '';
            case 'addvar': {
                const next = String(Number(env.variables[args[0]] ?? 0) + Number(args[1] ?? 0));
                env.variables[args[0]] = next;
                window.risu_context.variables[args[0]] = next;
                return '';
            }
            case 'gettempvar':
                return env.temp[args[0]] ?? '';
            case 'settempvar':
                env.temp[args[0]] = valueToString(args[1]);
                return '';
            case 'trim':
                return valueToString(args[0]).trim();
            case 'lower':
                return valueToString(args[0]).toLowerCase();
            case 'upper':
                return valueToString(args[0]).toUpperCase();
            case 'split': {
                const source = valueToString(args[0]);
                const delimiter = args.length > 1 ? valueToString(args[1]) : ',';
                if (!source) {
                    return '[]';
                }

                return JSON.stringify(source.split(delimiter));
            }
            case 'filter': {
                const values = parseRisuListLikeValue(args[0])
                    .map((entry) => valueToString(entry).trim())
                    .filter(Boolean);
                return JSON.stringify(values);
            }
            case 'spread': {
                const values = parseRisuListLikeValue(args[0])
                    .flatMap((entry) => {
                        const nested = parseRisuArrayValue(entry);
                        return nested ? nested.map((value) => valueToString(value)) : [valueToString(entry)];
                    })
                    .map((entry) => entry.trim())
                    .filter(Boolean);
                return JSON.stringify(values);
            }
            case 'random': {
                const values = parseRisuListLikeValue(args[0])
                    .map((entry) => valueToString(entry).trim())
                    .filter(Boolean);
                if (!values.length) {
                    return '';
                }

                return values[Math.floor(Math.random() * values.length)];
            }
            case 'startswith':
                return valueToString(args[0]).startsWith(valueToString(args[1])) ? '1' : '0';
            case 'endswith':
                return valueToString(args[0]).endsWith(valueToString(args[1])) ? '1' : '0';
            case 'contains':
                return valueToString(args[0]).includes(valueToString(args[1])) ? '1' : '0';
            case 'equal':
                return valueToString(args[0]) === valueToString(args[1]) ? '1' : '0';
            case 'not_equal':
                return valueToString(args[0]) !== valueToString(args[1]) ? '1' : '0';
            case 'greater':
                return Number(args[0] ?? 0) > Number(args[1] ?? 0) ? '1' : '0';
            case 'greater_equal':
                return Number(args[0] ?? 0) >= Number(args[1] ?? 0) ? '1' : '0';
            case 'less':
                return Number(args[0] ?? 0) < Number(args[1] ?? 0) ? '1' : '0';
            case 'less_equal':
                return Number(args[0] ?? 0) <= Number(args[1] ?? 0) ? '1' : '0';
            case 'lastmessageid':
                return String(env.lastMessageId);
            case 'chat_index':
                return String(env.chatIndex);
            case 'raw':
                return buildAssetUrl(env.assetOwner, valueToString(args[0]), env?.descriptor?.character);
            case 'bg': {
                const url = buildAssetUrl(env.assetOwner, valueToString(args[0]), env?.descriptor?.character);
                return url ? `<img src="${url}" style="position:fixed; top:0; left:0; width:100vw; height:100vh; object-fit:cover; z-index:-1; pointer-events:none;">` : '';
            }
            case 'audio': {
                const url = buildAssetUrl(env.assetOwner, valueToString(args[0]), env?.descriptor?.character);
                return url ? `<audio src="${url}" autoplay loop style="display:none;"></audio>` : '';
            }
            case 'img':
                return makeImgTag(env.assetOwner, valueToString(args[0]), env?.descriptor?.character);
            case 'button':
                return `<button class="menu_button risu-trigger-button" data-risu-trigger="${valueToString(args[1])}">${valueToString(args[0])}</button>`;
            default:
                return rawTag;
        }
    }

    function evaluateWhenCondition(conditionText, env) {
        const normalized = renderSimpleContent(conditionText, env);
        const parts = splitTopLevelByDoubleColon(normalized).map(part => part.trim());
        if (parts.length === 0) {
            return false;
        }

        let keepWhitespace = false;
        let legacyWhitespace = false;
        while (parts[0] === 'keep' || parts[0] === 'legacy') {
            if (parts[0] === 'keep') keepWhitespace = true;
            if (parts[0] === 'legacy') legacyWhitespace = true;
            parts.shift();
        }

        const evaluateAtom = (atomParts) => {
            if (atomParts.length === 0) {
                return false;
            }

            if (atomParts[0].toLowerCase() === 'not') {
                return !evaluateAtom(atomParts.slice(1));
            }

            if (atomParts[0].toLowerCase() === 'var' || atomParts[0].toLowerCase() === 'toggle') {
                return isTruthyRisuValue(atomParts[1] ?? '');
            }

            if (atomParts.length >= 3) {
                const left = valueToString(atomParts[0]);
                const operator = valueToString(atomParts[1]).toLowerCase();
                const right = valueToString(atomParts.slice(2).join('::'));
                if (operator === 'is' || operator === 'equal' || operator === 'vis' || operator === 'tis') return left === right;
                if (operator === 'isnot' || operator === 'not_equal' || operator === 'visnot' || operator === 'tisnot') return left !== right;
                if (operator === '>') return Number(left) > Number(right);
                if (operator === '>=') return Number(left) >= Number(right);
                if (operator === '<') return Number(left) < Number(right);
                if (operator === '<=') return Number(left) <= Number(right);
            }

            return isTruthyRisuValue(atomParts.join('::'));
        };

        const groups = [];
        const operators = [];
        let buffer = [];
        for (const part of parts) {
            const lowered = part.toLowerCase();
            if (lowered === 'and' || lowered === 'or') {
                groups.push(evaluateAtom(buffer));
                operators.push(lowered);
                buffer = [];
            } else {
                buffer.push(part);
            }
        }

        if (buffer.length > 0) {
            groups.push(evaluateAtom(buffer));
        }

        let current = groups[groups.length - 1] ?? false;
        for (let index = operators.length - 1; index >= 0; index--) {
            current = operators[index] === 'and'
                ? Boolean(groups[index]) && Boolean(current)
                : Boolean(groups[index]) || Boolean(current);
        }

        return keepWhitespace || legacyWhitespace ? Boolean(current) : Boolean(current);
    }

    function renderRisuTemplate(text, env, options = {}) {
        if (typeof text !== 'string' || !text) {
            return '';
        }

        text = restoreRisuTemplateText(text);

        let cursor = 0;
        let output = '';

        while (cursor < text.length) {
            const tagStart = text.indexOf('{{', cursor);
            if (tagStart === -1) {
                output += text.slice(cursor);
                break;
            }

            output += text.slice(cursor, tagStart);
            const tagEnd = findTagEnd(text, tagStart);
            if (tagEnd === -1) {
                output += text.slice(tagStart);
                break;
            }

            const tag = text.slice(tagStart, tagEnd);
            const tagContent = tag.slice(2, -2).trim();
            const tagType = getTagType(tagContent);

            if (options.allowBlocks !== false && tagType.kind === 'open') {
                const bounds = findBlockBounds(text, tagStart, tagType.block);
                if (!bounds) {
                    output += tag;
                    cursor = tagEnd;
                    continue;
                }

                const trueBranch = text.slice(bounds.openEnd, bounds.elseStart === -1 ? bounds.closeStart : bounds.elseStart);
                const falseBranch = bounds.elseStart === -1 ? '' : text.slice(bounds.elseEnd, bounds.closeStart);

                if (tagType.block === 'each') {
                    const eachContent = tagContent.replace(/^#each(?:::keep)?\s*/, '');
                    const asMatch = eachContent.match(/^(.*?)(?:\s+as\s+|\s+)([A-Za-z0-9_]+)\s*$/);
                    const sourceExpr = asMatch ? asMatch[1].trim() : eachContent.trim();
                    const alias = asMatch ? asMatch[2].trim() : 'item';
                    const resolvedSource = sourceExpr.startsWith('{{') && sourceExpr.endsWith('}}')
                        ? evaluateSimpleTag(sourceExpr, env, options)
                        : renderSimpleContent(sourceExpr, env, options);
                    const iterable = parseRisuArrayValue(resolvedSource) ?? (Array.isArray(resolvedSource) ? resolvedSource : null);

                    if (iterable) {
                        for (const entry of iterable) {
                            const previous = env.slots[alias];
                            env.slots[alias] = entry;
                            output += renderRisuTemplate(trueBranch, env, options);
                            if (previous === undefined) delete env.slots[alias];
                            else env.slots[alias] = previous;
                        }
                    } else {
                        output += valueToString(resolvedSource);
                    }
                } else {
                    const conditionContent = tagType.block === 'if'
                        ? tagContent.replace(/^#if\s+/, '')
                        : tagContent.replace(/^#when::/, '');
                    const isTrue = tagType.block === 'if'
                        ? isTruthyRisuValue(renderSimpleContent(conditionContent, env, options))
                        : evaluateWhenCondition(conditionContent, env);
                    output += renderRisuTemplate(isTrue ? trueBranch : falseBranch, env, options);
                }

                cursor = bounds.closeEnd;
                continue;
            }

            if (tagType.kind === 'else' || tagType.kind === 'close') {
                cursor = tagEnd;
                continue;
            }

            output += valueToString(evaluateSimpleTag(tag, env, options));
            cursor = tagEnd;
        }

        if (options.convertAssetTags !== false) {
            output = output.replace(/<img src=([^>\s]+)>/gi, (_, assetName) => makeImgTag(env.assetOwner, assetName, env?.descriptor?.character));
            output = output.replace(/<img="?([^">]+)"?>/gi, (_, assetName) => makeImgTag(env.assetOwner, assetName, env?.descriptor?.character));
        }
        return output;
    }

    function ensureRisuBackgroundRoot() {
        const host = document.getElementById('sheld') || document.getElementById('chat') || document.body;
        let bgEmbed = document.getElementById('risu_bg_embedding');
        let bgScope = document.getElementById('risu_bg_embedding_scope');

        if (!bgEmbed) {
            bgEmbed = document.createElement('div');
            bgEmbed.id = 'risu_bg_embedding';
        }

        if (bgEmbed.parentElement !== host) {
            host.prepend(bgEmbed);
        }

        Object.assign(bgEmbed.style, {
            position: host.id === 'sheld' ? 'absolute' : 'fixed',
            inset: '0',
            overflow: 'hidden',
            pointerEvents: 'none',
            zIndex: host.id === 'sheld' ? '31' : '2',
        });

        if (!bgScope) {
            bgScope = document.createElement('div');
            bgScope.id = 'risu_bg_embedding_scope';
            bgScope.className = 'risu_bg_scope';
            bgEmbed.appendChild(bgScope);
        }

        Object.assign(bgScope.style, {
            position: 'absolute',
            inset: '0',
            overflow: 'hidden',
            pointerEvents: 'none',
        });

        return { bgEmbed, bgScope };
    }

    async function sanitizeRisuBackgroundHtml(embedHtml) {
        const runtime = await runtimePromise;
        const chatsApi = runtime?.chatsApi;
        const DOMPurify = runtime?.libsApi?.DOMPurify;

        if (!embedHtml || !chatsApi?.encodeStyleTags || !chatsApi?.decodeStyleTags || !DOMPurify?.sanitize) {
            return compactRisuStructuredWidgetWhitespace(embedHtml);
        }

        const config = {
            RETURN_DOM: false,
            RETURN_DOM_FRAGMENT: false,
            RETURN_TRUSTED_TYPE: false,
            MESSAGE_SANITIZE: true,
            MESSAGE_ALLOW_SYSTEM_UI: true,
            ADD_TAGS: ['custom-style'],
        };

        let normalized = normalizeRisuHtmlAttributes(embedHtml);
        normalized = promoteRisuAssetBackgroundImages(normalized);
        normalized = chatsApi.encodeStyleTags(normalized);
        normalized = DOMPurify.sanitize(normalized, config);
        const messageScoped = chatsApi.decodeStyleTags(normalized, { prefix: '.mes_text ' });
        const backgroundScoped = chatsApi.decodeStyleTags(normalized, { prefix: '.risu_bg_scope ' });
        const styleRegex = /<style>[\s\S]*?<\/style>/g;
        const messageStyles = (messageScoped.match(styleRegex) || []).join('\n');
        normalized = `${messageStyles}${messageStyles ? '\n' : ''}${backgroundScoped}`;
        return compactRisuStructuredWidgetWhitespace(normalized);
    }

    async function sanitizeRisuMessageHtml(embedHtml) {
        const runtime = await runtimePromise;
        const chatsApi = runtime?.chatsApi;
        const DOMPurify = runtime?.libsApi?.DOMPurify;

        if (!embedHtml || !chatsApi?.encodeStyleTags || !chatsApi?.decodeStyleTags || !DOMPurify?.sanitize) {
            return preserveRisuMessageLineBreaks(compactRisuStructuredWidgetWhitespace(promoteRisuAssetBackgroundImages(normalizeRisuHtmlAttributes(embedHtml))));
        }

        const config = {
            RETURN_DOM: false,
            RETURN_DOM_FRAGMENT: false,
            RETURN_TRUSTED_TYPE: false,
            MESSAGE_SANITIZE: true,
            MESSAGE_ALLOW_SYSTEM_UI: true,
            ADD_TAGS: ['custom-style'],
        };

        let normalized = normalizeRisuHtmlAttributes(embedHtml);
        normalized = promoteRisuAssetBackgroundImages(normalized);
        normalized = chatsApi.encodeStyleTags(normalized);
        normalized = DOMPurify.sanitize(normalized, config);
        normalized = chatsApi.decodeStyleTags(normalized, { prefix: '.mes_text ' });
        return preserveRisuMessageLineBreaks(compactRisuStructuredWidgetWhitespace(normalized));
    }

    const RISU_LISABELLE_CARD_SELECTOR = '.lisabelle-card, .custom-lisabelle-card';
    const RISU_LISABELLE_IMAGE_SELECTOR = '.lisabelle-image-container, .custom-lisabelle-image-container';
    const RISU_LISABELLE_INFO_SELECTOR = '.lisabelle-info-card, .custom-lisabelle-info-card';
    const RISU_LISABELLE_INFO_DESC_SELECTOR = '.info-desc, .custom-info-desc';
    const RISU_STRUCTURED_FRAME_CONTENT_SELECTOR = [
        '.win-classic.win-imgframe .win-content',
        '.win-classic.win-imgframe .preview-box',
        '.custom-win-classic.custom-win-imgframe .custom-win-content',
        '.custom-win-classic.custom-win-imgframe .custom-preview-box',
    ].join(', ');
    const RISU_STRUCTURED_FRAME_IMAGE_SELECTOR = [
        '.win-classic.win-imgframe .esther-img',
        '.preview-image',
        '.custom-win-classic.custom-win-imgframe .custom-esther-img',
        '.custom-preview-image',
    ].join(', ');
    const RISU_BACKGROUND_INTERACTIVE_SELECTOR = [
        '[data-risu-trigger]',
        '[risu-trigger]',
        'button',
        'a',
        'label',
        'input',
        'select',
        'textarea',
        'audio',
        'video',
        '.lisabelle-wrapper',
        '.custom-lisabelle-wrapper',
        RISU_LISABELLE_CARD_SELECTOR,
        RISU_LISABELLE_IMAGE_SELECTOR,
        RISU_LISABELLE_INFO_SELECTOR,
        '.win-classic',
        '.custom-win-classic',
        '.desktop-note-status',
        '.custom-desktop-note-status',
        '.folder-client',
        '.custom-folder-client',
        '.note-window',
        '.custom-note-window',
        '.preview-box',
        '.custom-preview-box',
        '.report-grid',
        '.custom-report-grid',
        '.report-card',
        '.custom-report-card',
        '.report-chip',
        '.custom-report-chip',
        '.suha-ui-interface',
        '.suha-ui-floating-btn',
        '.suha-ui-overlay',
        '.suha-ui-side-panel',
        '.suha-ui-panel-inner',
        '.suha-ui-row',
        '.suha-ui-btns',
        '.suha-ui-btn',
        '.SH-img-sfw-container',
        '.SH-img-nsfw-container',
        '#startv1-panel',
        '.startv1-row',
        '.startv1-grid',
        '.startv1-btn',
        '.startv1-hero-grid',
        '.startv1-btn.heroine-btn',
        '#btn-asset-toggle',
    ].join(', ');

    function createRisuInfoParagraph() {
        const paragraph = document.createElement('p');
        paragraph.className = 'info-desc custom-info-desc';
        return paragraph;
    }

    function promoteRisuAssetBackgroundImages(html) {
        const markup = String(html || '');
        if (!markup || !markup.includes('background-image') || !markup.includes(assetBaseUrl)) {
            return markup;
        }

        const root = document.createElement('div');
        root.innerHTML = markup;

        root.querySelectorAll('[style*="background-image"]').forEach((element) => {
            if (!(element instanceof HTMLElement)) {
                return;
            }

            const classTokens = String(element.className || '').split(/\s+/).filter(Boolean);
            const isHoverPreviewWidget = classTokens.some((token) =>
                /^custom-?image-container-?/i.test(token)
                || /^image-container-?/i.test(token)
                || /^custom-?image-container$/i.test(token)
                || /^image-container$/i.test(token))
                || element.closest('.image-wrapper, .custom-image-wrapper')
                || element.matches('.image-container, .custom-image-container');

            // Prefer native CSS background rendering for structured Risu widgets.
            // These cards intentionally size/crop via background-size/background-position,
            // and promoting them to <img> can fight SillyTavern's global image styles
            // and leave empty frame space.
            if (isHoverPreviewWidget || element.matches('.esther-img, .preview-image, .lisabelle-image-container, .clea-tip-img, .custom-esther-img, .custom-preview-image, .custom-lisabelle-image-container, .custom-clea-tip-img')) {
                return;
            }

            if (element.children.length > 0 || element.textContent.trim()) {
                return;
            }

            const styleAttr = String(element.getAttribute('style') || '');
            const imageMatch = styleAttr.match(/background-image\s*:\s*url\((['"]?)(.*?)\1\)/i);
            if (!imageMatch?.[2]) {
                return;
            }

            const assetUrl = imageMatch[2].trim().replace(/&amp;/gi, '&');
            if (!assetUrl || !assetUrl.includes(assetBaseUrl)) {
                return;
            }

            const sizeMatch = styleAttr.match(/background-size\s*:\s*([^;]+)/i);
            const positionMatch = styleAttr.match(/background-position\s*:\s*([^;]+)/i);

            element.setAttribute('data-risu-promoted-bg', 'true');
            element.style.backgroundImage = 'none';

            const img = document.createElement('img');
            img.className = 'risu_promoted_bg_image';
            img.src = assetUrl;
            img.alt = '';
            img.draggable = false;
            img.style.objectFit = sizeMatch?.[1]?.trim() || 'cover';
            img.style.objectPosition = positionMatch?.[1]?.trim() || 'center center';
            element.appendChild(img);
        });

        return root.innerHTML;
    }

    function normalizeRisuInlineText(value) {
        return String(value || '').replace(/\s+/g, ' ').trim();
    }

    function stripWhitespaceTextNodes(element) {
        if (!(element instanceof HTMLElement)) {
            return;
        }

        for (const node of [...element.childNodes]) {
            if (node instanceof Text && !normalizeRisuInlineText(node.nodeValue)) {
                node.remove();
            }
        }
    }

    function compactRisuStructuredWidgetWhitespace(html) {
        const markup = String(html || '');
        if (!markup || (!markup.includes('lisabelle-card') && !markup.includes('win-imgframe'))) {
            return markup;
        }

        const root = document.createElement('div');
        root.innerHTML = markup;

        root.querySelectorAll(RISU_LISABELLE_CARD_SELECTOR).forEach((card) => {
            if (!(card instanceof HTMLElement)) {
                return;
            }

            stripWhitespaceTextNodes(card);
        });

        root.querySelectorAll(RISU_LISABELLE_INFO_SELECTOR).forEach((infoCard) => {
            if (!(infoCard instanceof HTMLElement)) {
                return;
            }

            infoCard.querySelectorAll('br').forEach((br) => br.remove());
            const label = normalizeRisuInlineText(infoCard.textContent);
            infoCard.replaceChildren();

            if (!label) {
                return;
            }

            const paragraph = createRisuInfoParagraph();
            paragraph.textContent = label;
            infoCard.appendChild(paragraph);
        });

        root.querySelectorAll(RISU_STRUCTURED_FRAME_CONTENT_SELECTOR).forEach((box) => {
            if (!(box instanceof HTMLElement)) {
                return;
            }

            stripWhitespaceTextNodes(box);
            box.querySelectorAll('br').forEach((br) => br.remove());
        });

        return root.innerHTML;
    }

    function normalizeRisuStructuredWidgetLayouts(root) {
        const scope = root?.jquery ? root[0] : root;
        if (!(scope instanceof HTMLElement)) {
            return;
        }

        const isBackgroundScope = scope.id === 'risu_bg_embedding_scope'
            || scope.classList.contains('risu_bg_scope')
            || Boolean(scope.closest?.('.risu_bg_scope'));

        if (!isBackgroundScope) {
            scope.querySelectorAll(RISU_LISABELLE_CARD_SELECTOR).forEach((card) => {
                if (!(card instanceof HTMLElement)) {
                    return;
                }

                stripWhitespaceTextNodes(card);
                card.style.whiteSpace = 'normal';
            });

            scope.querySelectorAll(RISU_LISABELLE_IMAGE_SELECTOR).forEach((imageContainer) => {
                if (!(imageContainer instanceof HTMLElement)) {
                    return;
                }

                imageContainer.style.display = 'block';
                imageContainer.style.margin = '0 auto';
                imageContainer.style.backgroundRepeat = 'no-repeat';
            });

            scope.querySelectorAll(RISU_LISABELLE_INFO_SELECTOR).forEach((infoCard) => {
                if (!(infoCard instanceof HTMLElement)) {
                    return;
                }

                const label = normalizeRisuInlineText(infoCard.textContent);
                infoCard.replaceChildren();

                if (label) {
                    const paragraph = createRisuInfoParagraph();
                    paragraph.textContent = label;
                    infoCard.appendChild(paragraph);
                }

                Object.assign(infoCard.style, {
                    display: 'block',
                    margin: '0',
                    padding: '8px 14px 10px',
                    minHeight: '0',
                    height: 'auto',
                    lineHeight: 'normal',
                });

                const desc = infoCard.querySelector(RISU_LISABELLE_INFO_DESC_SELECTOR);
                if (desc instanceof HTMLElement) {
                    Object.assign(desc.style, {
                        display: 'block',
                        margin: '0',
                        padding: '0',
                        lineHeight: '1.15',
                        whiteSpace: 'normal',
                    });
                }
            });
        }

        scope.querySelectorAll(RISU_STRUCTURED_FRAME_CONTENT_SELECTOR).forEach((box) => {
            if (!(box instanceof HTMLElement)) {
                return;
            }

            stripWhitespaceTextNodes(box);
            box.querySelectorAll('br').forEach((br) => br.remove());
            Object.assign(box.style, {
                padding: '0',
                margin: '0',
                fontSize: '0',
                lineHeight: '0',
            });
        });

        scope.querySelectorAll(RISU_STRUCTURED_FRAME_IMAGE_SELECTOR).forEach((imageFrame) => {
            if (!(imageFrame instanceof HTMLElement)) {
                return;
            }

            imageFrame.style.display = 'block';
            imageFrame.style.margin = '0';
            imageFrame.style.backgroundRepeat = 'no-repeat';
            imageFrame.style.fontSize = '0';
            imageFrame.style.lineHeight = '0';
        });

        normalizeRisuStatusWidgets(scope);
        hoistRisuStatusWidgets(scope);
    }

    function createRisuStatusTooltip(element, text) {
        const tooltip = document.createElement('div');
        tooltip.className = 'risu-status-tooltip';
        tooltip.textContent = text;
        Object.assign(tooltip.style, {
            position: 'absolute',
            top: '0',
            left: '0',
            right: 'auto',
            transform: 'none',
            minWidth: '12rem',
            maxWidth: 'min(18rem, 80vw)',
            padding: '16px 18px',
            backgroundColor: '#fffefdf7',
            color: '#6198d3',
            borderRadius: '30px',
            border: '3px solid #8ab8e9ef',
            fontFamily: '"omyu_pretty", sans-serif',
            fontSize: '0.85em',
            lineHeight: '1.6',
            whiteSpace: 'pre-wrap',
            textAlign: 'left',
            boxSizing: 'border-box',
            boxShadow: '0 10px 24px rgba(0,0,0,0.18)',
            pointerEvents: 'none',
            zIndex: '60',
        });

        return tooltip;
    }

    function positionRisuStatusTooltip(host, grid, tooltip) {
        if (!(host instanceof HTMLElement) || !(grid instanceof HTMLElement) || !(tooltip instanceof HTMLElement)) {
            return;
        }

        const hostRect = host.getBoundingClientRect();
        const gridRect = grid.getBoundingClientRect();
        const tooltipRect = tooltip.getBoundingClientRect();
        const gap = 10;
        const leftPadding = 6;
        const rightPadding = 6;
        let left = (hostRect.left - gridRect.left) + ((hostRect.width - tooltipRect.width) / 2);

        if (host.classList.contains('Iram') || host.classList.contains('custom-Iram')) {
            left = Math.max(leftPadding, hostRect.left - gridRect.left);
        } else if (host.classList.contains('user') || host.classList.contains('custom-user')) {
            left = (hostRect.right - gridRect.left) - tooltipRect.width;
        }

        const maxLeft = Math.max(leftPadding, gridRect.width - tooltipRect.width - rightPadding);
        left = Math.max(leftPadding, Math.min(left, maxLeft));

        tooltip.style.left = `${left}px`;
        tooltip.style.top = `${(hostRect.bottom - gridRect.top) + gap}px`;
    }

    function normalizeRisuStatusWidgets(scope) {
        const widgets = scope.querySelectorAll('.sisters-status-card, .custom-sisters-status-card');
        if (!widgets.length) {
            return;
        }

        widgets.forEach((card) => {
            if (!(card instanceof HTMLElement)) {
                return;
            }

            card.style.display = 'block';
            card.style.clear = 'both';
            card.style.margin = '12px auto 0';
            card.style.overflow = 'visible';
            card.style.position = 'relative';

            const grid = card.querySelector('.sisters-status-grid, .custom-sisters-status-grid');
            if (grid instanceof HTMLElement) {
                grid.style.overflow = 'visible';
                grid.style.position = 'relative';
            }

            card.querySelectorAll('.sisters-status-image, .custom-sisters-status-image').forEach((element) => {
                if (!(element instanceof HTMLElement)) {
                    return;
                }

                const infoText = String(element.getAttribute('data-risu-status-info') || element.getAttribute('data-info') || '').trim();
                if (!infoText) {
                    return;
                }

                element.setAttribute('data-risu-status-info', infoText);
                element.removeAttribute('data-info');
                element.style.position = 'relative';
                element.style.overflow = 'visible';
                element.style.zIndex = '1';

                if (element.dataset.risuStatusManaged === '1') {
                    return;
                }

                const showTooltip = () => {
                    const tooltipHost = grid instanceof HTMLElement ? grid : element;
                    if (!(tooltipHost instanceof HTMLElement)) {
                        return;
                    }

                    const existingTooltip = tooltipHost.querySelector(':scope > .risu-status-tooltip');
                    if (existingTooltip instanceof HTMLElement) {
                        positionRisuStatusTooltip(element, tooltipHost, existingTooltip);
                        element.style.zIndex = '61';
                        return;
                    }

                    const tooltip = createRisuStatusTooltip(element, infoText);
                    tooltipHost.appendChild(tooltip);
                    positionRisuStatusTooltip(element, tooltipHost, tooltip);
                    element.style.zIndex = '61';
                };

                const hideTooltip = () => {
                    const tooltipHost = grid instanceof HTMLElement ? grid : element;
                    tooltipHost.querySelector(':scope > .risu-status-tooltip')?.remove();
                    element.style.zIndex = '1';
                };

                element.addEventListener('mouseenter', showTooltip);
                element.addEventListener('mouseleave', hideTooltip);
                element.addEventListener('focusin', showTooltip);
                element.addEventListener('focusout', hideTooltip);
                element.dataset.risuStatusManaged = '1';
            });
        });
    }

    function hoistRisuStatusWidgets(scope) {
        if (!(scope instanceof HTMLElement) || scope.classList.contains('risu_bg_scope')) {
            return;
        }

        const statusCard = scope.querySelector(':scope > .sisters-status-card, :scope > .custom-sisters-status-card')
            || scope.querySelector('.sisters-status-card, .custom-sisters-status-card');
        if (!(statusCard instanceof HTMLElement)) {
            return;
        }

        const firstMeaningfulNode = Array.from(scope.childNodes).find((node) => {
            if (node === statusCard) {
                return false;
            }

            if (node.nodeType === Node.TEXT_NODE) {
                return Boolean(String(node.nodeValue || '').trim());
            }

            if (!(node instanceof HTMLElement)) {
                return false;
            }

            if (node.matches('style, custom-style, script')) {
                return false;
            }

            return true;
        });

        if (!firstMeaningfulNode) {
            scope.prepend(statusCard);
            return;
        }

        if (firstMeaningfulNode !== statusCard) {
            scope.insertBefore(statusCard, firstMeaningfulNode);
        }
    }

    function preserveRisuMessageLineBreaks(html) {
        const markup = String(html || '');
        if (!markup || !markup.includes('\n')) {
            return markup;
        }

        const mediaBlockSelector = [
            '.win-imgframe',
            '.img-err',
            '.container',
            '.custom-container',
        ].join(', ');

        const container = document.createElement('div');
        container.innerHTML = markup;
        const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
        const textNodes = [];

        let currentNode = walker.nextNode();
        while (currentNode) {
            textNodes.push(currentNode);
            currentNode = walker.nextNode();
        }

        for (const node of textNodes) {
            if (!(node instanceof Text)) {
                continue;
            }

            const parentElement = node.parentElement;
            if (!parentElement) {
                continue;
            }

            if (parentElement.closest('style, script, pre, code, textarea, custom-style')) {
                continue;
            }

            // Leave structured Risu widgets alone. Esther's windowed UI and similar
            // HTML panels rely on their own layout, and inserting <br> nodes into
            // those subtrees can distort hitboxes and interaction behavior.
            if (parentElement.closest([
                '[data-risu-trigger]',
                '[risu-trigger]',
                'button',
                'label',
                'a',
                'input',
                'select',
                'option',
                '.win-classic',
                '.desktop-note-status',
                '.win-imgframe',
                '.img-err',
                '.folder-client',
                '.note-window',
                '.preview-box',
                '.report-grid',
                '.report-card',
                '.report-chip',
                '.lisabelle-wrapper',
                '.lisabelle-card',
                '.lisabelle-image-container',
                '.lisabelle-info-card',
                '.custom-lisabelle-wrapper',
                '.custom-lisabelle-card',
                '.custom-lisabelle-image-container',
                '.custom-lisabelle-info-card',
                '.custom-win-classic',
                '.custom-win-imgframe',
                '.custom-preview-box',
                '.custom-desktop-note-status',
                '.custom-img-err',
                '.custom-folder-client',
                '.custom-note-window',
                '.custom-report-grid',
                '.custom-report-card',
                '.custom-report-chip',
            ].join(', '))) {
                continue;
            }

            let value = String(node.nodeValue || '').replace(/\r\n?/g, '\n');
            if (!value.trim()) {
                continue;
            }

            if (!value.includes('\n')) {
                continue;
            }

            // Risu image/template regex often leaves many empty control-tag lines
            // around block media. Collapse those runs before turning newlines into
            // <br> so Esther-style image frames don't create giant empty walls.
            value = value.replace(/\n(?:[ \t]*\n){2,}/g, '\n\n');

            let previousElement = node.previousSibling;
            while (previousElement && !(previousElement instanceof Element)) {
                previousElement = previousElement.previousSibling;
            }

            let nextElement = node.nextSibling;
            while (nextElement && !(nextElement instanceof Element)) {
                nextElement = nextElement.nextSibling;
            }

            if (previousElement?.matches?.(mediaBlockSelector) || previousElement?.closest?.(mediaBlockSelector)) {
                value = value.replace(/^(?:[ \t]*\n)+/g, '\n\n');
            }

            if (nextElement?.matches?.(mediaBlockSelector) || nextElement?.closest?.(mediaBlockSelector)) {
                value = value.replace(/(?:\n[ \t]*)+$/g, '\n\n');
            }

            const parts = value.split('\n');
            const fragment = document.createDocumentFragment();
            parts.forEach((part, index) => {
                if (part) {
                    fragment.appendChild(document.createTextNode(part));
                }

                if (index < parts.length - 1) {
                    fragment.appendChild(document.createElement('br'));
                }
            });

            node.replaceWith(fragment);
        }

        return container.innerHTML;
    }

    function ensureRisuExtensionStyles() {
        if (document.getElementById('risuai_extension_styles')) {
            return;
        }

        const style = document.createElement('style');
        style.id = 'risuai_extension_styles';
        style.textContent = `
            .mes_text .risu-comment-note {
                display: block;
                margin: 8px 0;
                padding: 10px 14px;
                background: rgba(255, 255, 255, 0.04);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 6px;
                color: inherit;
                line-height: 1.4;
                white-space: normal;
            }

            .mes_text .risu-comment-inline-code {
                display: inline-block;
                margin: 0 2px;
                padding: 1px 6px;
                border-radius: 6px;
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.12);
                font-family: Consolas, "Courier New", monospace;
                font-size: 0.95em;
                color: inherit;
                white-space: nowrap;
            }

            .mes_text img.roundedImage {
                display: block;
                width: auto;
                height: auto;
                max-width: min(20vw, 22rem);
                max-height: min(70vh, 38rem);
                margin-inline: auto;
            }

            .mes_text .container img.roundedImage {
                object-fit: cover;
                object-position: center;
                border-radius: 10px;
                aspect-ratio: 832 / 1216;
            }

            [data-risu-promoted-bg="true"] {
                position: relative;
                overflow: hidden;
            }

            [data-risu-promoted-bg="true"] > .risu_promoted_bg_image {
                position: absolute;
                inset: 0;
                width: 100%;
                height: 100%;
                display: block;
                max-width: none !important;
                max-height: none !important;
                min-width: 100%;
                min-height: 100%;
                pointer-events: none;
                user-select: none;
                z-index: 0;
            }

            .mes_text:not(.risu_bg_scope) .lisabelle-card,
            .mes_text:not(.risu_bg_scope) .custom-lisabelle-card {
                width: min(100%, 31rem);
                margin: 12px auto;
                white-space: normal !important;
                display: inline-flex !important;
                flex-direction: column !important;
                align-items: stretch !important;
                gap: 0 !important;
            }

            .mes_text:not(.risu_bg_scope) .lisabelle-image-container,
            .mes_text:not(.risu_bg_scope) .custom-lisabelle-image-container {
                width: 100% !important;
                height: 31rem !important;
                max-width: 100%;
                box-sizing: border-box !important;
                background-repeat: no-repeat !important;
                background-size: cover !important;
                background-position: center 10% !important;
                font-size: 0 !important;
                line-height: 0 !important;
            }

            .mes_text:not(.risu_bg_scope) .lisabelle-image-container:hover,
            .mes_text:not(.risu_bg_scope) .custom-lisabelle-image-container:hover {
                height: 43rem !important;
            }

            .mes_text:not(.risu_bg_scope) .lisabelle-info-card,
            .mes_text:not(.risu_bg_scope) .custom-lisabelle-info-card {
                padding: 8px 14px 10px !important;
                white-space: normal !important;
                min-height: 0 !important;
                height: auto !important;
            }

            .mes_text:not(.risu_bg_scope) .lisabelle-info-card .info-desc,
            .mes_text:not(.risu_bg_scope) .lisabelle-info-card .custom-info-desc,
            .mes_text:not(.risu_bg_scope) .custom-lisabelle-info-card .info-desc,
            .mes_text:not(.risu_bg_scope) .custom-lisabelle-info-card .custom-info-desc {
                display: block !important;
                margin: 0 !important;
                padding: 0 !important;
                line-height: 1.15 !important;
                white-space: normal !important;
            }

            .mes_text .win-classic.win-imgframe .win-content,
            .mes_text .win-classic.win-imgframe .preview-box,
            .mes_text .custom-win-classic.custom-win-imgframe .custom-win-content,
            .mes_text .custom-win-classic.custom-win-imgframe .custom-preview-box {
                padding: 0 !important;
                margin: 0 !important;
                font-size: 0 !important;
                line-height: 0 !important;
            }

            .mes_text .win-classic.win-imgframe .esther-img,
            .mes_text .preview-image,
            .mes_text .custom-win-classic.custom-win-imgframe .custom-esther-img,
            .mes_text .custom-preview-image {
                display: block !important;
                margin: 0 !important;
                background-repeat: no-repeat !important;
            }

            .mes_text .sisters-status-card,
            .risu_bg_scope .sisters-status-card {
                display: block !important;
                clear: both !important;
                margin: 12px auto 0 !important;
                overflow: visible !important;
                position: relative !important;
            }

            .mes_text .sisters-status-grid,
            .risu_bg_scope .sisters-status-grid {
                overflow: visible !important;
                position: relative !important;
            }

            .mes_text .sisters-status-image,
            .risu_bg_scope .sisters-status-image {
                position: relative !important;
                overflow: visible !important;
                z-index: 1 !important;
            }

            .mes_text .sisters-status-image::before,
            .risu_bg_scope .sisters-status-image::before,
            .mes_text .custom-sisters-status-image::before,
            .risu_bg_scope .custom-sisters-status-image::before {
                content: none !important;
                display: none !important;
                opacity: 0 !important;
                visibility: hidden !important;
            }

            .mes_text .sisters-status-image.Iram::before,
            .risu_bg_scope .sisters-status-image.Iram::before {
                left: 0 !important;
                transform: none !important;
            }

            .mes_text .sisters-status-image.user::before,
            .risu_bg_scope .sisters-status-image.user::before {
                left: auto !important;
                right: 0 !important;
                transform: none !important;
            }

            .risu_bg_scope .win-classic.win-imgframe .win-content,
            .risu_bg_scope .win-classic.win-imgframe .preview-box,
            .risu_bg_scope .custom-win-classic.custom-win-imgframe .custom-win-content,
            .risu_bg_scope .custom-win-classic.custom-win-imgframe .custom-preview-box {
                padding: 0 !important;
                margin: 0 !important;
                font-size: 0 !important;
                line-height: 0 !important;
            }

            .risu_bg_scope .win-classic.win-imgframe .esther-img,
            .risu_bg_scope .preview-image,
            .risu_bg_scope .custom-win-classic.custom-win-imgframe .custom-esther-img,
            .risu_bg_scope .custom-preview-image {
                display: block !important;
                margin: 0 !important;
                background-repeat: no-repeat !important;
            }

            .risu_bg_scope .lisabelle-wrapper,
            .risu_bg_scope .custom-lisabelle-wrapper {
                pointer-events: auto !important;
            }

            .risu_bg_scope .lisabelle-card,
            .risu_bg_scope .custom-lisabelle-card,
            .risu_bg_scope .lisabelle-image-container,
            .risu_bg_scope .custom-lisabelle-image-container,
            .risu_bg_scope .lisabelle-info-card,
            .risu_bg_scope .custom-lisabelle-info-card {
                pointer-events: auto !important;
            }

            @media (max-width: 768px) {
                .mes_text img.roundedImage {
                    max-width: 80vw;
                    max-height: 70vh;
                }

                .mes_text:not(.risu_bg_scope) .lisabelle-card,
                .mes_text:not(.risu_bg_scope) .custom-lisabelle-card {
                    width: min(100%, 18.5rem);
                }

                .mes_text:not(.risu_bg_scope) .lisabelle-image-container,
                .mes_text:not(.risu_bg_scope) .custom-lisabelle-image-container {
                    height: 18.5rem !important;
                }

                .mes_text:not(.risu_bg_scope) .lisabelle-image-container:hover,
                .mes_text:not(.risu_bg_scope) .custom-lisabelle-image-container:hover {
                    height: 27rem !important;
                }

            }

            body.risu_hide_st_expression_layers .expression-holder,
            body.risu_hide_st_expression_layers .zoomed_avatar:not([data-risu-managed-zoom="true"]),
            body.risu_hide_st_expression_layers img.expression,
            body.risu_hide_st_expression_layers #expression-image {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
            }

            #risuai_trigger_script_container .risuai_trigger_help {
                margin: 0 0 8px;
                opacity: 0.85;
                font-size: 0.9em;
                line-height: 1.4;
            }

            #risuai_trigger_script_textarea {
                min-height: 180px;
                font-family: Consolas, "Courier New", monospace;
            }

            #risuai_trigger_script_textarea.risuai_invalid {
                border-color: #d97777 !important;
                box-shadow: 0 0 0 1px rgba(217, 119, 119, 0.35);
            }

            .risuai_portrait_host {
                position: relative;
            }

            #avatar_div_div.risuai_portrait_host {
                display: inline-flex;
                align-items: center;
                justify-content: center;
            }

            .risuai_portrait_navigator {
                position: absolute;
                inset-inline: 6px;
                bottom: 6px;
                z-index: 30;
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 6px;
                padding: 4px 6px;
                border-radius: 999px;
                background: rgba(10, 14, 24, 0.74);
                backdrop-filter: blur(6px);
                box-shadow: 0 6px 18px rgba(0, 0, 0, 0.28);
            }

            .risuai_portrait_navigator.risuai_portrait_hoveronly {
                opacity: 0;
                pointer-events: none;
                transition: opacity 0.18s ease;
            }

            .risuai_portrait_host:hover > .risuai_portrait_navigator.risuai_portrait_hoveronly,
            .risuai_portrait_host:focus-within > .risuai_portrait_navigator.risuai_portrait_hoveronly {
                opacity: 1;
                pointer-events: auto;
            }

            .risuai_portrait_button {
                border: 0;
                min-width: 28px;
                height: 28px;
                border-radius: 999px;
                background: rgba(255, 255, 255, 0.14);
                color: inherit;
                cursor: pointer;
                font-size: 15px;
                line-height: 1;
            }

            .risuai_portrait_button:hover {
                background: rgba(255, 255, 255, 0.22);
            }

            .risuai_portrait_status {
                flex: 1;
                min-width: 0;
                text-align: center;
                font-size: 0.8rem;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }

            #avatar_div_div > .risuai_portrait_navigator {
                left: 50%;
                right: auto;
                inset-inline: auto;
                transform: translateX(-50%);
                min-width: 74px;
                width: max-content;
            }
        `;
        document.head.appendChild(style);
    }

    function updateRisuExpressionVisibility(descriptor) {
        document.body.classList.toggle('risu_hide_st_expression_layers', Boolean(descriptor && descriptor.isLargePortrait !== true));
    }

    function restoreManagedRisuPortraits() {
        document.querySelectorAll('img[data-risu-managed-portrait="true"]').forEach((image) => {
            const originalSrc = image.dataset.risuOriginalAvatarSrc || '';
            const originalZoomSrc = image.dataset.risuOriginalZoomSrc || '';

            if (originalSrc) {
                image.setAttribute('src', originalSrc);
            }

            if (image.hasAttribute('data-izoomify-url')) {
                image.setAttribute('data-izoomify-url', originalZoomSrc || originalSrc);
            }

            delete image.dataset.risuManagedPortrait;
            delete image.dataset.risuOriginalAvatarSrc;
            delete image.dataset.risuOriginalZoomSrc;
            delete image.dataset.risuCurrentManagedPortraitUrl;
        });

        document.querySelectorAll('.risuai_portrait_navigator').forEach((node) => node.remove());
        document.querySelectorAll('.risuai_portrait_host').forEach((node) => node.classList.remove('risuai_portrait_host'));
    }

    function getPortraitNavigatorTargets(descriptor = null) {
        const targets = [];
        const activeName = String(descriptor?.character?.name || '').trim();
        const selectedAvatarHost = document.getElementById('avatar_div_div');
        const selectedAvatarImage = document.getElementById('avatar_load_preview');
        if (selectedAvatarHost && selectedAvatarImage) {
            targets.push({
                host: selectedAvatarHost,
                image: selectedAvatarImage,
                kind: 'editor',
            });
        }

        const messageCandidates = Array.from(document.querySelectorAll('#chat .mes[is_user="false"]:not([is_system="true"])'))
            .filter((message) => {
                if (!activeName) {
                    return true;
                }

                const messageName = String(
                    message.getAttribute('ch_name')
                    || message.querySelector('.name_text')?.textContent
                    || '',
                ).trim();

                return !messageName || messageName === activeName;
            });

        const latestAvatarHost = messageCandidates
            .map((message) => message.querySelector('.mesAvatarWrapper'))
            .filter((node) => node?.querySelector('.avatar img'))
            .pop();

        if (latestAvatarHost) {
            targets.push({
                host: latestAvatarHost,
                image: latestAvatarHost.querySelector('.avatar img'),
                kind: 'chat',
            });
        }

        document.querySelectorAll('.zoomed_avatar[forChar]').forEach((host) => {
            const image = host.querySelector('.zoomed_avatar_img');
            if (!image) {
                return;
            }

            targets.push({
                host,
                image,
                kind: 'zoom',
            });
        });

        return targets;
    }

    function ensurePortraitNavigator(host, descriptor, kind = 'editor') {
        if (!host || !descriptor) {
            return;
        }

        if (kind === 'chat' || kind === 'zoom') {
            host.querySelector('.risuai_portrait_navigator')?.remove();
            host.classList.remove('risuai_portrait_host');
            return;
        }

        const portraits = Array.isArray(descriptor.portraitAssets) ? descriptor.portraitAssets : [];
        if (portraits.length <= 1) {
            host.querySelector('.risuai_portrait_navigator')?.remove();
            host.classList.remove('risuai_portrait_host');
            return;
        }

        host.classList.add('risuai_portrait_host');
        let navigator = host.querySelector('.risuai_portrait_navigator');
        if (!navigator) {
            navigator = document.createElement('div');
            navigator.className = 'risuai_portrait_navigator';
            navigator.innerHTML = `
                <button type="button" class="risuai_portrait_button" data-risu-portrait-nav="-1" aria-label="Previous portrait">&lt;</button>
                <div class="risuai_portrait_status"></div>
                <button type="button" class="risuai_portrait_button" data-risu-portrait-nav="1" aria-label="Next portrait">&gt;</button>
            `;
            navigator.addEventListener('click', (event) => {
                event.preventDefault();
                event.stopPropagation();
                const button = event.target.closest('[data-risu-portrait-nav]');
                if (!button) {
                    return;
                }

                const activeDescriptor = getActiveRisuDescriptor();
                if (!activeDescriptor) {
                    return;
                }

                const direction = Number(button.getAttribute('data-risu-portrait-nav'));
                const currentIndex = getSelectedRisuPortraitIndex(activeDescriptor);
                setSelectedRisuPortraitIndex(activeDescriptor, currentIndex + direction);
                const refreshedDescriptor = getActiveRisuDescriptor();
                const refreshedUrl = getSelectedRisuPortraitUrl(refreshedDescriptor);
                const hostImage = host.querySelector(kind === 'zoom' ? '.zoomed_avatar_img' : 'img');
                if (refreshedDescriptor && refreshedUrl && hostImage) {
                    applyManagedPortraitToTarget({ host, image: hostImage, kind }, refreshedDescriptor, refreshedUrl);
                }
                syncActiveRisuPortrait();
            });
            host.appendChild(navigator);
        }

        const isHoverOnly = kind === 'zoom';
        navigator.classList.toggle('risuai_portrait_hoveronly', isHoverOnly);
        navigator.style.insetInline = kind === 'editor' ? '0' : '6px';
        navigator.style.bottom = kind === 'editor' ? '-10px' : '6px';
        navigator.style.padding = kind === 'editor' ? '4px 6px' : '4px 6px';
        navigator.querySelectorAll('.risuai_portrait_button').forEach((button) => {
            button.style.minWidth = kind === 'editor' ? '28px' : '28px';
            button.style.height = kind === 'editor' ? '28px' : '28px';
        });

        const portrait = getSelectedRisuPortrait(descriptor);
        const index = getSelectedRisuPortraitIndex(descriptor);
        const status = navigator.querySelector('.risuai_portrait_status');
        if (status) {
            status.textContent = kind === 'editor'
                ? `${index + 1}/${portraits.length}`
                : `${index + 1}/${portraits.length} ${portrait?.label || ''}`.trim();
            status.title = portrait?.label || '';
        }
    }

    function applyManagedPortraitToTarget(target, descriptor, selectedUrl) {
        const { host, image, kind } = target || {};
        if (!host || !image || !selectedUrl) {
            return;
        }

        const previousManagedUrl = String(image.dataset.risuCurrentManagedPortraitUrl || '');

        if (kind === 'zoom') {
            image.dataset.risuOriginalAvatarSrc = selectedUrl;
            image.dataset.risuOriginalZoomSrc = selectedUrl;
        } else if (!image.dataset.risuOriginalAvatarSrc) {
            image.dataset.risuOriginalAvatarSrc = image.getAttribute('src') || '';
        }

        if (image.hasAttribute('data-izoomify-url') && kind !== 'zoom' && !image.dataset.risuOriginalZoomSrc) {
            image.dataset.risuOriginalZoomSrc = image.getAttribute('data-izoomify-url') || '';
        }

        if (image.getAttribute('src') !== selectedUrl) {
            image.setAttribute('src', selectedUrl);
        }

        if (image.hasAttribute('data-izoomify-url')) {
            image.setAttribute('data-izoomify-url', selectedUrl);
        }

        image.dataset.risuManagedPortrait = 'true';
        image.dataset.risuCurrentManagedPortraitUrl = selectedUrl;
        ensurePortraitNavigator(host, descriptor, kind);

        if (kind === 'zoom' && previousManagedUrl !== selectedUrl && typeof $.fn.izoomify === 'function') {
            const zoomContainer = image.closest('.zoomed_avatar_container');
            const zoomHost = zoomContainer ? $(zoomContainer) : $();
            zoomHost.trigger('izoomify.destroy');
            image.setAttribute('src', selectedUrl);
            image.setAttribute('data-izoomify-url', selectedUrl);

            if (zoomHost.length && runtimeApi?.powerUserApi?.power_user?.zoomed_avatar_magnification) {
                zoomHost.izoomify();
            }
        }
    }

    function syncActiveRisuPortrait() {
        const descriptor = getActiveRisuDescriptor();
        if (!descriptor) {
            restoreManagedRisuPortraits();
            return;
        }

        const portraits = Array.isArray(descriptor.portraitAssets) ? descriptor.portraitAssets : [];
        if (portraits.length <= 1) {
            restoreManagedRisuPortraits();
            return;
        }

        const selectedUrl = getSelectedRisuPortraitUrl(descriptor);
        if (!selectedUrl) {
            restoreManagedRisuPortraits();
            return;
        }

        const targets = getPortraitNavigatorTargets(descriptor);
        if (!targets.length) {
            return;
        }

        targets.forEach((target) => applyManagedPortraitToTarget(target, descriptor, selectedUrl));
    }

    function toggleManagedRisuZoom(messageElement, descriptor) {
        const selectedUrl = getSelectedRisuPortraitUrl(descriptor);
        if (!selectedUrl) {
            return false;
        }

        const runtime = runtimeApi;
        const animationDuration = Number(runtime?.scriptApi?.animation_duration) || 125;
        const powerUser = runtime?.powerUserApi?.power_user;
        const dragElement = runtime?.rossApi?.dragElement;
        const loadMovingUIState = runtime?.powerUserApi?.loadMovingUIState;
        const zoomKey = pathFromName(descriptor?.avatar || descriptor?.assetOwner || descriptor?.character?.name || 'risu_portrait');
        const safeZoomId = sanitizeName(zoomKey || 'risu_portrait');
        const existing = $(`.zoomed_avatar[forChar="${zoomKey}"]`);

        if (existing.length) {
            existing.fadeOut(animationDuration, () => {
                existing.remove();
            });
            return true;
        }

        if (!powerUser?.movingUI) {
            $('.zoomed_avatar').each(function () {
                const currentForChar = $(this).attr('forChar');
                if (currentForChar !== zoomKey && typeof currentForChar !== 'undefined') {
                    $(this).remove();
                }
            });
        }

        const template = $('#zoomed_avatar_template').html();
        if (!template) {
            return false;
        }

        const newElement = $(template);
        newElement.find('.risuai_portrait_navigator').remove();
        newElement.removeClass('risuai_portrait_host');
        newElement.attr('forChar', zoomKey);
        newElement.attr('id', `zoomFor_${safeZoomId}`);
        newElement.attr('data-risu-managed-zoom', 'true');
        newElement.addClass('draggable');
        newElement.find('.drag-grabber').attr('id', `zoomFor_${safeZoomId}header`);

        $('body').append(newElement);
        newElement.fadeIn(animationDuration);

        const zoomedAvatarImgElement = newElement.find('.zoomed_avatar_img');
        zoomedAvatarImgElement.removeAttr('data-risu-managed-portrait data-risu-original-avatar-src data-risu-original-zoom-src data-risu-current-managed-portrait-url');
        zoomedAvatarImgElement.attr('src', selectedUrl);
        zoomedAvatarImgElement.attr('data-izoomify-url', selectedUrl);

        if (typeof loadMovingUIState === 'function') {
            loadMovingUIState();
        }

        newElement.css('display', 'flex');
        if (typeof dragElement === 'function') {
            dragElement(newElement);
        }

        if (powerUser?.zoomed_avatar_magnification && typeof $.fn.izoomify === 'function') {
            newElement.find('.zoomed_avatar_container').izoomify();
        }

        newElement.on('click touchend', '.dragClose', (event) => {
            event.preventDefault();
            event.stopPropagation();
            newElement.fadeOut(animationDuration, () => {
                newElement.remove();
            });
        });

        zoomedAvatarImgElement.on('dragstart', (event) => {
            event.preventDefault();
            return false;
        });

        setTimeout(() => {
            syncActiveRisuPortrait();
        }, 0);

        return true;
    }

    async function updateRisuBackground(embedSource, descriptor) {
        const { bgScope } = ensureRisuBackgroundRoot();
        const renderVersion = ++backgroundRenderVersion;

        if (!embedSource && descriptor?.isLargePortrait) {
            bgScope.innerHTML = '';
            lastBackgroundRenderSignature = '';
            return;
        }

        const env = createRisuEnv(descriptor, -1);
        let embedHtml = renderRisuTemplate(embedSource || '', env);

        if (embedHtml && !embedHtml.includes('<style') && !embedHtml.includes('<div') && embedHtml.includes('{') && embedHtml.includes('}')) {
            embedHtml = `<style>${embedHtml}</style>`;
        }

        embedHtml = await sanitizeRisuBackgroundHtml(embedHtml);

        if (renderVersion !== backgroundRenderVersion) {
            return;
        }

        const backgroundSignature = `${descriptor?.avatar || descriptor?.assetOwner || descriptor?.character?.name || ''}\u0000${embedHtml}`;
        if (backgroundSignature === lastBackgroundRenderSignature) {
            return;
        }

        bgScope.innerHTML = embedHtml;
        lastBackgroundRenderSignature = backgroundSignature;
        normalizeRisuStructuredWidgetLayouts(bgScope);

        bgScope.querySelectorAll(RISU_BACKGROUND_INTERACTIVE_SELECTOR).forEach((node) => {
            node.style.pointerEvents = 'auto';
            node.style.position = node.style.position || 'relative';
            node.style.zIndex = node.style.zIndex || '1';
        });
    }

    function renderActiveBackground() {
        const descriptor = getActiveRisuDescriptor();
        updateRisuExpressionVisibility(descriptor);
        syncActiveRisuPortrait();
        if (!descriptor) {
            lastBackgroundRenderSignature = '';
            updateRisuBackground('', { isLargePortrait: true });
            return;
        }

        const embedSource = getCombinedBackgroundEmbedding(descriptor.character);
        updateRisuBackground(embedSource, descriptor);
    }

    function isBackgroundGenerationActive() {
        const context = getContext();
        const processor = context?.streamingProcessor;
        return Boolean(processor && !processor.isFinished && !processor.isStopped);
    }

    function flushDeferredBackgroundRender() {
        if (!backgroundRenderDeferredDuringGeneration) {
            return;
        }

        backgroundRenderDeferredDuringGeneration = false;
        scheduleBackgroundRender({ force: true });
    }

    function scheduleBackgroundRender(options = {}) {
        const force = Boolean(options?.force);
        if (!force && isBackgroundGenerationActive()) {
            backgroundRenderDeferredDuringGeneration = true;
            return;
        }

        if (backgroundRenderScheduled) {
            return;
        }

        backgroundRenderScheduled = true;
        setTimeout(() => {
            backgroundRenderScheduled = false;
            if (!force && isBackgroundGenerationActive()) {
                backgroundRenderDeferredDuringGeneration = true;
                return;
            }
            renderActiveBackground();
        }, 0);
    }

    function hasRisuMessageSourceMarkup(html) {
        const text = String(html || '');
        return text.includes('{{')
            || containsProtectedRisuTemplate(text)
            || text.includes('risu-trigger=')
            || /<img[^>]*\bsrc\s*=\s*["']?(?!\/api\/plugins\/risuai-importer\/asset\b|https?:|data:|blob:)[^"'\s>]+/i.test(text);
    }

    function getRisuSystemMessagePrefix(card) {
        const rules = Array.isArray(getRisuModule(card)?.regex) ? getRisuModule(card).regex : [];
        for (const rule of rules) {
            const output = String(rule?.out || '');
            if (!output.includes('sysmsg')) {
                continue;
            }

            const match = String(rule?.in || '').match(/\\\[(.*?)(?:\(\.\+\?\)|\.\*\?)\\\]/);
            if (match?.[1]) {
                return match[1];
            }
        }

        return 'SYSTEM: ';
    }

    async function appendRisuNoteToLastCharacterMessage(note) {
        const context = getContext();
        const chat = Array.isArray(context?.chat) ? context.chat : null;
        if (!chat?.length || !note) {
            return false;
        }

        for (let index = chat.length - 1; index >= 0; index--) {
            const message = chat[index];
            if (!message || message.is_user || message.is_system) {
                continue;
            }

            const current = String(message.mes || '');
            if (current.includes(note)) {
                return true;
            }

            message.mes = current ? `${current}\n\n${note}` : note;

            const runtime = await runtimePromise;
            runtime?.scriptApi?.saveChatDebounced?.();

            if (runtime?.scriptApi?.eventSource?.emit && runtime?.scriptApi?.event_types?.MESSAGE_UPDATED) {
                await runtime.scriptApi.eventSource.emit(runtime.scriptApi.event_types.MESSAGE_UPDATED, index);
            }

            if (runtime?.scriptApi?.eventSource?.emit && runtime?.scriptApi?.event_types?.CHAT_CHANGED) {
                await runtime.scriptApi.eventSource.emit(
                    runtime.scriptApi.event_types.CHAT_CHANGED,
                    typeof runtime.scriptApi.getCurrentChatId === 'function' ? runtime.scriptApi.getCurrentChatId() : null,
                );
            }

            return true;
        }

        return false;
    }

    async function showRisuNormalAlert(message) {
        const text = String(message || '').trim();
        if (!text) {
            return;
        }

        if (window.toastr?.info) {
            window.toastr.info(text);
            return;
        }

        console.info('[Risu Trigger]', text);
    }

    async function requestRisuInput(message) {
        const runtime = await runtimePromise;
        if (runtime?.popupApi?.callGenericPopup && runtime?.popupApi?.POPUP_TYPE?.INPUT) {
            const result = await runtime.popupApi.callGenericPopup(String(message || ''), runtime.popupApi.POPUP_TYPE.INPUT, '', { wider: true });
            return typeof result === 'string' ? result : '';
        }

        return String(window.prompt(String(message || '')) || '');
    }

    async function runCleaTrigger(trigger, label = '') {
        const descriptor = getActiveRisuDescriptor();
        const character = descriptor?.character;
        if (!character) {
            return false;
        }

        const vars = window.risu_context.variables;
        const prefix = getRisuSystemMessagePrefix(character);
        const setValue = (key, value) => { vars[key] = String(value); };
        const appendSystem = async (message) => appendRisuNoteToLastCharacterMessage(`[${prefix}${message}]`);
        const notify = async (message) => showRisuNormalAlert(message);

        if (/^cleaMode\d+$/.test(trigger)) {
            const mode = trigger.replace('cleaMode', '');
            const labelText = label || `Mode ${mode}`;
            setValue('clea_mode', mode);
            await appendSystem(`${labelText} selected.`);
            await notify(`${labelText} selected.`);
            return true;
        }

        if (/^cleaSense[123]$/.test(trigger)) {
            const level = trigger.slice(-1);
            const labelText = label || `Sensitivity ${level}`;
            setValue('clea_sense', level);
            await appendSystem(`Sensitivity changed to ${labelText}.`);
            await notify(`Sensitivity changed to ${labelText}.`);
            return true;
        }

        if (/^cleaObscene[123]$/.test(trigger)) {
            const level = trigger.slice(-1);
            const labelText = label || `Obscene level ${level}`;
            setValue('clea_obscene', level);
            await appendSystem(`Obscene level changed to ${labelText}.`);
            await notify(`Obscene level changed to ${labelText}.`);
            return true;
        }

        if (trigger === 'cleaCustomMode') {
            const input = (await requestRisuInput('Enter a custom mode name.')).trim();
            if (!input) {
                return false;
            }

            setValue('clea_mode', 'custom');
            setValue('clea_custom_mode', input);
            await appendSystem(`Custom mode '${input}' selected.`);
            await notify(`Custom mode '${input}' selected.`);
            return true;
        }

        return false;
    }

    function applyRisuMessageImageFixes(messageText) {
        if (!messageText?.length) {
            return;
        }

        const portraitMaxWidth = window.innerWidth <= 768 ? '80vw' : '20vw';
        const portraitMaxHeight = window.innerWidth <= 768 ? '70vh' : '38rem';

        messageText.find('.container, .custom-container').each(function () {
            this.style.display = 'grid';
            this.style.placeItems = 'center';
            this.style.width = '100%';
            this.style.position = 'relative';
        });

        messageText.find('img.roundedImage, img.custom-roundedImage').each(function () {
            this.style.display = 'block';
            this.style.margin = '10px auto';
            this.style.width = '100%';
            this.style.maxWidth = portraitMaxWidth;
            this.style.maxHeight = portraitMaxHeight;
            this.style.height = 'auto';
            this.style.aspectRatio = this.style.aspectRatio || '832 / 1216';
            this.style.objectFit = 'cover';
            this.style.borderRadius = '10px';
        });

        messageText.find(`img[src*="${assetBaseUrl}"]`).each(function () {
            if (this.classList.contains('mes_img') || this.closest('.mes_media_container')) {
                return;
            }

            const className = this.className || '';
            const insidePortraitContainer = this.closest('.container, .custom-container');
            const isPortraitImage = insidePortraitContainer || className.includes('roundedImage') || className.includes('custom-roundedImage');

            if (!isPortraitImage) {
                return;
            }

            this.style.display = 'block';
            this.style.margin = '10px auto';
            this.style.width = '100%';
            this.style.maxWidth = portraitMaxWidth;
            this.style.maxHeight = portraitMaxHeight;
            this.style.height = 'auto';
            this.style.objectFit = 'cover';
            this.style.borderRadius = '10px';
        });
    }

    async function processMessageElement(messageElement) {
        const descriptor = getActiveRisuDescriptor();
        if (!descriptor || !messageElement?.length) return;

        const messageText = messageElement.find('.mes_text');
        if (!messageText.length) return;
        if (messageElement.find('.edit_textarea, .reasoning_edit_textarea').length > 0
            || messageElement.find('.mes_edit_buttons:visible').length > 0) {
            return;
        }

        const currentHtml = messageText.html() || '';
        const storedSource = messageText.data('risuSource');
        const messageId = Number(messageElement.attr('mesid'));
        const runtime = await runtimePromise;
        const chat = Array.isArray(runtime?.scriptApi?.chat) ? runtime.scriptApi.chat : [];
        const chatMessage = Number.isFinite(messageId) ? chat[messageId] : null;
        const chatSource = typeof chatMessage?.mes === 'string' ? chatMessage.mes : '';
        const firstCharacterMessageId = getFirstCharacterMessageId(chat);
        const isFirstCharacterMessage = Number.isFinite(messageId) && messageId === firstCharacterMessageId;

        const env = createRisuEnv(descriptor, Number.isFinite(messageId) ? messageId : -1);
        const resolvedCardData = await getResolvedRisuCardData(descriptor);
        const rawFirstMessage = isFirstCharacterMessage
            ? (descriptor.character?.first_mes || resolvedCardData?.first_mes || descriptor.character?.data?.first_mes || '')
            : '';
        const selectedSwipeIndex = Number(chatMessage?.swipe_id);
        const swipeCount = Array.isArray(chatMessage?.swipes) ? chatMessage.swipes.length : 0;
        const hasAnySelectedSwipe = swipeCount > 0
            && Number.isInteger(selectedSwipeIndex)
            && selectedSwipeIndex >= 0
            && selectedSwipeIndex < swipeCount;
        const selectedSwipeSource = hasAnySelectedSwipe
            ? chatMessage.swipes[selectedSwipeIndex]
            : '';
        const hasEmptySelectedSwipe = isFirstCharacterMessage
            && hasAnySelectedSwipe
            && !String(selectedSwipeSource ?? '').trim();
        const alternateGreetings = [
            ...(Array.isArray(descriptor.character?.alternate_greetings) ? descriptor.character.alternate_greetings : []),
            ...(Array.isArray(resolvedCardData?.alternate_greetings) ? resolvedCardData.alternate_greetings : []),
            ...(Array.isArray(descriptor.character?.data?.alternate_greetings) ? descriptor.character.data.alternate_greetings : []),
        ].map(entry => restoreRisuTemplateText(String(entry || '')).trim()).filter(Boolean);
        const restoredChatSource = restoreRisuTemplateText(String(chatSource || '')).trim();
        const restoredSwipeSource = restoreRisuTemplateText(String(selectedSwipeSource || '')).trim();
        const isAlternateGreetingSource = Boolean(restoredChatSource) && alternateGreetings.includes(restoredChatSource);
        const isAlternateGreetingSwipe = isFirstCharacterMessage
            && Boolean(restoredSwipeSource)
            && alternateGreetings.includes(restoredSwipeSource);
        const shouldPreferSelectedSwipeSource = isFirstCharacterMessage
            && hasAnySelectedSwipe
            && (
                !rawFirstMessage
                || hasEmptySelectedSwipe
                || swipeCount > 1
                || selectedSwipeIndex > 0
                || isAlternateGreetingSwipe
            );
        const hasValidSelectedSwipe = shouldPreferSelectedSwipeSource;
        const hasSelectedSwipeSource = hasValidSelectedSwipe && Boolean(restoredSwipeSource);
        const shouldUseChatSourceForFirstMessage = isFirstCharacterMessage
            && Boolean(restoredChatSource)
            && (isAlternateGreetingSource
                || hasRisuMessageSourceMarkup(chatSource)
                || isLikelyMangledRisuSource(chatSource)
                || isLikelyRawRisuFirstMessage(chatSource));
        const primaryRawSource = hasSelectedSwipeSource
            ? selectedSwipeSource
            : shouldUseChatSourceForFirstMessage
            ? chatSource
            : ((typeof rawFirstMessage === 'string' && rawFirstMessage) ? rawFirstMessage : chatSource);

        if (isFirstCharacterMessage) {
            ensureFirstCharacterMessageLoops(messageId);
        }

        let sourceHtml = (hasValidSelectedSwipe || hasEmptySelectedSwipe)
            ? String(selectedSwipeSource ?? '')
            : (primaryRawSource || storedSource || currentHtml);
        if (typeof sourceHtml === 'string' && sourceHtml) {
            sourceHtml = normalizeRisuDisplaySource(sourceHtml);
            sourceHtml = applyRisuOutputScripts(sourceHtml, env);
            sourceHtml = applyRisuDisplayScripts(sourceHtml, env);
            sourceHtml = normalizeRisuDisplaySource(sourceHtml);
        }

        if ((hasValidSelectedSwipe || hasEmptySelectedSwipe) && !String(sourceHtml || '').trim()) {
            messageText.empty();
            messageText.data('risuSource', '');
            return;
        }

        if (!sourceHtml) {
            const sourceCandidates = [storedSource, currentHtml].filter(value => typeof value === 'string' && value);
            sourceHtml = sourceCandidates.find(hasRisuMessageSourceMarkup)
                || sourceCandidates.find(isLikelyMangledRisuSource)
                || currentHtml;
        }

        sourceHtml = normalizeRisuDisplaySource(sourceHtml);

        const shouldProcess = Boolean(primaryRawSource)
            || hasRisuMessageSourceMarkup(sourceHtml)
            || isLikelyMangledRisuSource(sourceHtml)
            || isLikelyRawRisuFirstMessage(sourceHtml);
        if (!shouldProcess) return;

        messageText.data('risuSource', sourceHtml);
        const renderToken = Number(messageText.data('risuRenderToken') || 0) + 1;
        messageText.data('risuRenderToken', renderToken);
        let rendered = renderRisuTemplate(sourceHtml, env, { renderComments: true });
        rendered = await sanitizeRisuMessageHtml(rendered);

        if (Number(messageText.data('risuRenderToken')) !== renderToken) {
            return;
        }

        if (rendered !== currentHtml) {
            suppressChatObserver++;
            messageText.html(rendered);
            queueMicrotask(() => {
                suppressChatObserver = Math.max(0, suppressChatObserver - 1);
            });
        }

        normalizeRisuStructuredWidgetLayouts(messageText[0]);
        applyRisuMessageImageFixes(messageText);
    }

    function processRenderedMessage(messageId) {
        void processMessageElement($(`#chat .mes[mesid="${messageId}"]`));
    }

    function ensureFirstCharacterMessageLoops(messageId = null) {
        const runtime = runtimeApi;
        const chat = Array.isArray(runtime?.scriptApi?.chat) ? runtime.scriptApi.chat : [];
        const firstCharacterMessageId = getFirstCharacterMessageId(chat);
        const targetMessageId = Number.isFinite(messageId) ? messageId : firstCharacterMessageId;

        if (!Number.isFinite(firstCharacterMessageId) || firstCharacterMessageId < 0 || targetMessageId !== firstCharacterMessageId) {
            return;
        }

        const message = chat[targetMessageId];
        const swipeCount = Array.isArray(message?.swipes) ? message.swipes.length : 0;
        if (!message || swipeCount < 1) {
            return;
        }

        message.extra = message.extra || {};
        if (typeof message.extra.overswipe_behavior !== 'string' || message.extra.overswipe_behavior === 'regenerate') {
            message.extra.overswipe_behavior = 'loop';
        }
    }

    let refreshFirstCharacterPending = false;
    function refreshFirstCharacterMessageSoon(delays = [0, 150]) {
        if (refreshFirstCharacterPending) {
            return;
        }

        const runtime = runtimeApi;
        const chat = Array.isArray(runtime?.scriptApi?.chat) ? runtime.scriptApi.chat : [];
        const firstCharacterMessageId = getFirstCharacterMessageId(chat);
        if (!Number.isFinite(firstCharacterMessageId) || firstCharacterMessageId < 0) {
            return;
        }

        refreshFirstCharacterPending = true;
        const maxDelay = Math.max(...delays.map(d => Math.max(0, Number(d) || 0)));
        setTimeout(() => {
            refreshFirstCharacterPending = false;
            ensureFirstCharacterMessageLoops(firstCharacterMessageId);
            processRenderedMessage(firstCharacterMessageId);
        }, maxDelay);
    }

    function processAllRisuMessages() {
        $('#chat .mes').each(function () {
            void processMessageElement($(this));
        });
    }

    function hookGreetingSwipeGuard() {
        document.addEventListener('click', (event) => {
            const target = event.target instanceof Element ? event.target : null;
            const swipeButton = target?.closest?.('.swipe_right, .swipe_left');
            if (!swipeButton) {
                return;
            }

            const messageElement = swipeButton.closest('.mes');
            const messageId = Number(messageElement?.getAttribute('mesid'));
            const runtime = runtimeApi;
            const chat = Array.isArray(runtime?.scriptApi?.chat) ? runtime.scriptApi.chat : [];
            const firstCharacterMessageId = getFirstCharacterMessageId(chat);
            if (!Number.isFinite(messageId) || messageId !== firstCharacterMessageId) {
                return;
            }

            const chatMessage = chat[messageId];
            const swipeCount = Array.isArray(chatMessage?.swipes) ? chatMessage.swipes.length : 0;
            if (swipeCount > 1) {
                return;
            }

            event.preventDefault();
            event.stopPropagation();
            if (typeof event.stopImmediatePropagation === 'function') {
                event.stopImmediatePropagation();
            }

            if (chatMessage) {
                chatMessage.swipe_id = 0;
            }
            ensureFirstCharacterMessageLoops(messageId);
            processRenderedMessage(messageId);
        }, true);
    }

    async function applyKnownTrigger(trigger, options = {}) {
        const descriptor = getActiveRisuDescriptor();
        const vars = window.risu_context.variables;
        const setValue = (key, value) => { vars[key] = String(value); };
        const label = String(options.label || '').trim();

        const manualTrigger = descriptor ? getManualRisuTriggers(descriptor.character).find((entry) => String(entry.comment || '') === trigger) : null;
        if (manualTrigger && applyRisuTriggerEffects(manualTrigger.effect, vars)) {
            return true;
        }

        if (/^setScenario\d+$/.test(trigger)) {
            setValue('cv_scenario', trigger.replace('setScenario', ''));
            return true;
        }

        if (trigger === 'setLangKo') { setValue('cv_lang', 'ko'); return true; }
        if (trigger === 'setLangEn') { setValue('cv_lang', 'en'); return true; }
        if (trigger === 'set_lang_ko') { setValue('ui_lang', '0'); return true; }
        if (trigger === 'set_lang_en') { setValue('ui_lang', '1'); return true; }
        if (trigger === 'set_lang_jp') { setValue('ui_lang', '2'); return true; }
        if (trigger === 'toggle_character_asset') {
            const current = String(vars.CharacterAsset ?? '1');
            const next = current === '1' ? '0' : '1';
            setValue('CharacterAsset', next);
            setValue('asset', next);
            return true;
        }
        if (/^start_scen_[1-4]$/.test(trigger)) {
            setValue('scenario', trigger.replace('start_scen_', ''));
            return true;
        }
        if (trigger === 'startSelectedScenario') { setValue('cv_started', 1); return true; }
        if (trigger === 'resetStartScreen') {
            setValue('cv_started', 0);
            setValue('cv_scenario', 0);
            return true;
        }

        const toggleMap = {
            setOptAssetOn: ['cv_opt_asset', 1],
            setOptAssetOff: ['cv_opt_asset', 0],
            setOptNsfwOn: ['cv_opt_nsfw', 1],
            setOptNsfwOff: ['cv_opt_nsfw', 0],
            setOptStatuswindowOn: ['cv_opt_statuswindow', 1],
            setOptStatuswindowOff: ['cv_opt_statuswindow', 0],
            setOptEstherOn: ['cv_opt_esther', 1],
            setOptEstherOff: ['cv_opt_esther', 0],
        };

        if (toggleMap[trigger]) {
            const [key, value] = toggleMap[trigger];
            setValue(key, value);
            return true;
        }

        if (trigger === 'setAllOptionsOn' || trigger === 'setAllOptionsOff') {
            const value = trigger.endsWith('On') ? 1 : 0;
            setValue('cv_opt_asset', value);
            setValue('cv_opt_nsfw', value);
            setValue('cv_opt_statuswindow', value);
            setValue('cv_opt_esther', value);
            return true;
        }

        if (trigger === 'secretOpen') { setValue('cv_secret', 1); return true; }
        if (trigger === 'secretClose') { setValue('cv_secret', 0); return true; }
        if (trigger === 'setOptExtraOn') { setValue('cv_opt_extra', 1); return true; }
        if (trigger === 'setOptExtraOff') { setValue('cv_opt_extra', 0); return true; }

        if (await runCleaTrigger(trigger, label)) {
            return true;
        }

        return false;
    }

    function hookTriggerButtons() {
        document.addEventListener('click', async (event) => {
            const target = event.target.closest('[data-risu-trigger], [risu-trigger]');
            if (!target) return;

            const trigger = target.getAttribute('data-risu-trigger') || target.getAttribute('risu-trigger');
            if (!trigger) return;

            // Intercept Risu trigger clicks synchronously so downstream UI handlers
            // don't process the same click before our async trigger logic completes.
            event.preventDefault();
            event.stopPropagation();
            if (typeof event.stopImmediatePropagation === 'function') {
                event.stopImmediatePropagation();
            }

            if (await applyKnownTrigger(trigger, { label: target.textContent || '' })) {
                const messageNode = target.closest('.mes');
                if (messageNode) {
                    void processMessageElement($(messageNode));
                } else {
                    // Only re-render the first character message — trigger buttons
                    // in the background overlay change variables that affect only
                    // the greeting/scenario display, not every chat message.
                    refreshFirstCharacterMessageSoon();
                }
                scheduleBackgroundRender({ force: true });
            }
        }, true);
    }

    const originalFetch = window.fetch;
    window.fetch = async function (...args) {
        try {
            const url = typeof args[0] === 'string' ? args[0] : (args[0] instanceof Request ? args[0].url : '');

            if (url.includes('/api/characters/all')) {
                const response = await originalFetch.apply(this, args);
                if (response.ok) {
                    const risuChars = await getRisuCharacters();
                    const data = await response.clone().json();
                    risuChars.forEach((risuChar) => {
                        if (!data.find(existing => existing.avatar === risuChar.avatar)) {
                            data.push({ ...risuChar, shallow: true });
                        }
                    });
                    return new Response(JSON.stringify(data), { headers: response.headers, status: response.status });
                }
                return response;
            }

            if (url.includes('/api/characters/get')) {
                const response = await originalFetch.apply(this, args);
                if (!response.ok) return response;

                let avatar = '';
                try {
                    avatar = JSON.parse(args[1]?.body || '{}').avatar_url || '';
                } catch {
                    avatar = '';
                }

                const payload = await response.clone().json();

                if (avatar.endsWith('.charx')) {
                    const metadata = await getRisuMetadata(avatar);
                    if (metadata?.data) {
                        const processed = augmentRisuCharacterPayload(payload, avatar, metadata.data, metadata.module);
                        return new Response(JSON.stringify(processed), { status: response.status, headers: { 'Content-Type': 'application/json' } });
                    }
                } else if (isRisuPayload(payload, avatar)) {
                    const metadata = await recoverRisuMetadata(payload, avatar);
                    const processed = augmentRisuCharacterPayload(payload, avatar, null, metadata?.module || null);
                    return new Response(JSON.stringify(processed), { status: response.status, headers: { 'Content-Type': 'application/json' } });
                } else {
                    const metadata = await recoverRisuMetadata(payload, avatar);
                    if (metadata?.data || metadata?.module) {
                        const processed = augmentRisuCharacterPayload(payload, avatar, metadata.data || null, metadata.module || null);
                        return new Response(JSON.stringify(processed), { status: response.status, headers: { 'Content-Type': 'application/json' } });
                    }
                }

                return response;
            }
        } catch (error) {
            console.warn('[RisuAI Importer] fetch hook failed', error);
        }

        return originalFetch.apply(this, args);
    };

    function injectRisuBgUI() {
        if ($('#risuai_bg_html_container').length === 0 && $('#post_history_instructions_textarea').length > 0) {
            const editorHtml = `
                <div id="risuai_bg_html_container" style="margin-top:10px;">
                    <hr>
                    <h4 class="flex-container alignItemsBaseline">
                        <span data-i18n="Background Embedding HTML (RisuAI)">Background Embedding HTML (RisuAI)</span>
                        <i class="editor_maximize fa-solid fa-maximize right_menu_button" data-for="risuai_bg_html_textarea" title="Expand the editor"></i>
                    </h4>
                    <textarea id="risuai_bg_html_textarea" name="risuai_bg_html" placeholder="Raw HTML for Background Embedding..." class="text_pole" autocomplete="off" rows="3"></textarea>
                </div>
                <div id="risuai_trigger_script_container" style="margin-top:10px;">
                    <h4 class="flex-container alignItemsBaseline">
                        <span data-i18n="Trigger Script (RisuAI)">Trigger Script (RisuAI)</span>
                        <i class="editor_maximize fa-solid fa-maximize right_menu_button" data-for="risuai_trigger_script_textarea" title="Expand the editor"></i>
                    </h4>
                    <p class="risuai_trigger_help">
                        Trigger scripts can run on start, input, output, or button clicks. Paste Lua code for single-script cards, or JSON for full trigger arrays.
                    </p>
                    <textarea id="risuai_trigger_script_textarea" name="risuai_trigger_script" placeholder="Lua trigger code or JSON trigger array..." class="text_pole" autocomplete="off" rows="8"></textarea>
                </div>
            `;
            $('#post_history_instructions_textarea').parent().after(editorHtml);

            runtimePromise.then((runtime) => {
                if (!runtime) return;
                const { eventSource, event_types, characters, saveCharacterDebounced } = runtime.scriptApi;

                function renderBackgroundForCharacter(characterId) {
                    if (characterId === undefined || !characters[characterId]) return;
                    const character = characters[characterId];
                    if (!isRisuPayload(character, character.avatar || '')) {
                        updateRisuBackground('', { isLargePortrait: true });
                        return;
                    }

                    const descriptor = getActiveRisuDescriptor();
                    if (descriptor) {
                        updateRisuBackground(getCombinedBackgroundEmbedding(character), descriptor);
                    }
                }

                function syncEditorFields(characterId) {
                    if (characterId === undefined || !characters[characterId]) {
                        $('#risuai_bg_html_textarea').val('');
                        $('#risuai_trigger_script_textarea').val('').removeClass('risuai_invalid').attr('title', '');
                        return;
                    }

                    const character = characters[characterId];
                    $('#risuai_bg_html_textarea').val(getRisuData(character)?.backgroundHTML || '');
                    $('#risuai_trigger_script_textarea')
                        .val(getRisuTriggerEditorValue(character))
                        .removeClass('risuai_invalid')
                        .attr('title', '');
                }

                function ensureCharacterRisuData(character) {
                    character.data = character.data || {};
                    character.data.extensions = character.data.extensions || {};
                    character.data.extensions.risuai = character.data.extensions.risuai || {};
                    character.data.extensions.risuai.charxModule = character.data.extensions.risuai.charxModule || {};
                    return character.data.extensions.risuai;
                }

                $('#risuai_bg_html_textarea').on('input', function () {
                    const context = getContext();
                    const characterId = context?.characterId;
                    if (characterId === undefined || !characters[characterId]) return;

                    const character = characters[characterId];
                    ensureCharacterRisuData(character).backgroundHTML = $(this).val();
                    if (typeof saveCharacterDebounced === 'function') {
                        saveCharacterDebounced();
                    }
                    renderActiveBackground();
                });

                $('#risuai_trigger_script_textarea').on('input', function () {
                    const context = getContext();
                    const characterId = context?.characterId;
                    if (characterId === undefined || !characters[characterId]) return;

                    const character = characters[characterId];
                    const risuData = ensureCharacterRisuData(character);
                    const existingTriggers = getRisuTriggers(character);
                    const rawValue = $(this).val();

                    try {
                        risuData.charxModule.trigger = parseRisuTriggerEditorValue(rawValue, existingTriggers);
                        $(this).removeClass('risuai_invalid').attr('title', '');

                        if (typeof saveCharacterDebounced === 'function') {
                            saveCharacterDebounced();
                        }

                        const avatar = character.avatar || '';
                        delete window.risu_context.variables[`__risu_seeded__${avatar}`];
                        seedRisuVariablesFromTriggers(character);
                        processAllRisuMessages();
                        renderActiveBackground();
                    } catch (error) {
                        $(this)
                            .addClass('risuai_invalid')
                            .attr('title', String(error?.message || error || 'Invalid trigger script'));
                    }
                });

                eventSource.on(event_types.CHARACTER_EDITOR_OPENED, (characterId) => {
                    if (characterId === undefined || !characters[characterId]) return;
                    syncEditorFields(characterId);
                    renderBackgroundForCharacter(characterId);
                });

                eventSource.on(event_types.CHAT_LOADED, () => {
                    const context = getContext();
                    if (context?.characterId !== undefined) {
                        syncEditorFields(context.characterId);
                        renderBackgroundForCharacter(context.characterId);
                    } else {
                        syncEditorFields(undefined);
                    }
                });
            });
        } else if ($('#risuai_bg_html_container').length === 0) {
            setTimeout(injectRisuBgUI, 1000);
        }
    }

    function setupPortraitFix() {
        const fix = () => {
            $('img').each(function () {
                const src = $(this).attr('src') || '';
                if (src.includes('.charx') && !src.includes('api/plugins')) {
                    const filename = src.includes('file=') ? src.split('file=')[1].split('&')[0] : src.split('/').pop().split('?')[0];
                    if (filename.endsWith('.charx')) {
                        $(this).attr('src', `${avatarBaseUrl}?name=${encodeURIComponent(filename)}`);
                    }
                }
            });

            $('[style*="background-image"]').each(function () {
                const backgroundImage = $(this).css('background-image') || '';
                if (backgroundImage.includes('.charx') && !backgroundImage.includes('api/plugins')) {
                    let filename = '';
                    if (backgroundImage.includes('file=')) {
                        const match = backgroundImage.match(/file=([^&")]+)/);
                        if (match) filename = match[1].replace(/['"]/g, '');
                    } else {
                        const match = backgroundImage.match(/url\(['"]?(.*?\/([^/]+?\.charx).*?)['"]?\)/);
                        if (match) filename = match[2].split('?')[0];
                    }

                    if (filename && filename.endsWith('.charx')) {
                        $(this).css('background-image', `url('${avatarBaseUrl}?name=${encodeURIComponent(filename)}')`);
                    }
                }
            });

            syncActiveRisuPortrait();
        };

        setInterval(fix, 1000);
    }

    function hookPortraitNavigatorInteractions() {
        if (document.body.dataset.risuPortraitNavigatorHooked === 'true') {
            return;
        }

        document.body.dataset.risuPortraitNavigatorHooked = 'true';
        document.addEventListener('click', (event) => {
            const avatar = event.target.closest('.mes .avatar');
            if (!avatar) {
                return;
            }

            const image = avatar.querySelector('img[data-risu-managed-portrait="true"]');
            const messageElement = avatar.closest('.mes');
            if (!image || !messageElement || messageElement.getAttribute('is_user') === 'true') {
                return;
            }

            const descriptor = getActiveRisuDescriptor();
            if (!descriptor) {
                return;
            }

            event.preventDefault();
            event.stopPropagation();
            event.stopImmediatePropagation();
            toggleManagedRisuZoom($(messageElement), descriptor);
        }, true);

        document.addEventListener('click', (event) => {
            const zoomedImage = event.target.closest('.zoomed_avatar_img[data-risu-managed-portrait="true"]');
            if (!zoomedImage) {
                return;
            }

            event.preventDefault();
            event.stopPropagation();
        }, true);

        document.addEventListener('click', (event) => {
            if (!event.target.closest('.mesAvatarWrapper .avatar img, .zoomed_avatar_img')) {
                return;
            }

            setTimeout(() => {
                syncActiveRisuPortrait();
            }, 50);
        });

    }

    function createImportUI() {
        if ($('#risuai_file_input').length === 0) {
            $('body').append('<input type="file" id="risuai_file_input" accept=".charx" style="display:none;">');
            $('#risuai_file_input').on('change', function () {
                if (this.files && this.files[0]) {
                    const formData = new FormData();
                    formData.append('avatar', this.files[0]);
                    formData.append('file_type', 'charx');

                    fetch('/csrf-token')
                        .then(response => response.json())
                        .then(tokenResponse => fetch('/api/characters/import', {
                            method: 'POST',
                            body: formData,
                            headers: { 'X-CSRF-Token': tokenResponse.token },
                        }))
                        .then(() => {
                            const context = getContext();
                            if (context?.getCharacters) context.getCharacters();
                        })
                        .catch(error => console.warn('[RisuAI Importer] CharX import failed', error));
                }
                this.value = '';
            });
        }

        let container = $('#rm_button_group');
        if (container.length === 0) container = $('#character_import_button').parent();
        if (container.length && $('#risuai_import_char_btn').length === 0) {
            const button = $('<div id="risuai_import_char_btn" class="menu_button" title="Import RisuAI .charx" style="min-width:unset; width:40px;"><i class="fa-solid fa-file-arrow-up" style="color:#ff99cc;"></i></div>');
            button.on('click', () => $('#risuai_file_input').trigger('click'));
            container.append(button);
        }
    }

    async function hookRuntimeEvents() {
        const runtime = await runtimePromise;
        if (!runtime) return;

        const { eventSource, event_types } = runtime.scriptApi;
        eventSource.on(event_types.CHARACTER_MESSAGE_RENDERED, (messageId) => {
            processRenderedMessage(messageId);
            scheduleBackgroundRender();
            syncActiveRisuPortrait();
        });
        eventSource.on(event_types.MESSAGE_UPDATED, (messageId) => {
            processRenderedMessage(messageId);
            syncActiveRisuPortrait();
        });
        eventSource.on(event_types.MESSAGE_EDITED, (messageId) => {
            processRenderedMessage(messageId);
            scheduleBackgroundRender();
            syncActiveRisuPortrait();
        });
        if (event_types.MESSAGE_SWIPED) {
            eventSource.on(event_types.MESSAGE_SWIPED, (messageId) => {
                ensureFirstCharacterMessageLoops(messageId);
                processRenderedMessage(messageId);
                syncActiveRisuPortrait();

                const runtime = runtimeApi;
                const chat = Array.isArray(runtime?.scriptApi?.chat) ? runtime.scriptApi.chat : [];
                const firstCharacterMessageId = getFirstCharacterMessageId(chat);
                if (Number(messageId) === firstCharacterMessageId) {
                    refreshFirstCharacterMessageSoon([40, 150]);
                }
            });
        }
        eventSource.on(event_types.CHAT_LOADED, () => {
            processAllRisuMessages();
            scheduleBackgroundRender();
            ensureActiveCharacterRegexAllowed();
            syncActiveRisuPortrait();
        });
        if (event_types.CHAT_CHANGED) {
            eventSource.on(event_types.CHAT_CHANGED, () => {
                processAllRisuMessages();
                scheduleBackgroundRender();
                ensureActiveCharacterRegexAllowed();
                syncActiveRisuPortrait();
            });
        }
        if (event_types.GENERATION_ENDED) {
            eventSource.on(event_types.GENERATION_ENDED, () => {
                flushDeferredBackgroundRender();
            });
        }
        if (event_types.GENERATION_STOPPED) {
            eventSource.on(event_types.GENERATION_STOPPED, () => {
                flushDeferredBackgroundRender();
            });
        }

        let observerScheduled = false;
        const pendingObservedMessageIds = new Set();
        const queueObservedMessage = (messageElement) => {
            if (!(messageElement instanceof HTMLElement)) {
                return;
            }
            const messageId = Number(messageElement.getAttribute('mesid'));
            if (Number.isFinite(messageId)) {
                pendingObservedMessageIds.add(messageId);
            }
        };
        const scheduleProcessing = () => {
            if (observerScheduled) return;
            observerScheduled = true;
            setTimeout(() => {
                observerScheduled = false;
                const messageIds = [...pendingObservedMessageIds];
                pendingObservedMessageIds.clear();
                if (!messageIds.length) {
                    return;
                }
                messageIds.forEach((messageId) => processRenderedMessage(messageId));
                syncActiveRisuPortrait();
            }, 0);
        };

        const attachObserver = () => {
            const chat = document.getElementById('chat');
            if (!chat || chat.dataset.risuObserverAttached === 'true') {
                return;
            }

            const observer = new MutationObserver((mutations) => {
                if (suppressChatObserver > 0) {
                    return;
                }
                for (const mutation of mutations) {
                    if (mutation.type !== 'childList' && mutation.type !== 'characterData') {
                        continue;
                    }

                    if (mutation.target instanceof HTMLElement) {
                        queueObservedMessage(mutation.target.closest('.mes'));
                    } else if (mutation.target?.parentElement instanceof HTMLElement) {
                        queueObservedMessage(mutation.target.parentElement.closest('.mes'));
                    }

                    for (const node of mutation.addedNodes || []) {
                        if (!(node instanceof HTMLElement)) {
                            continue;
                        }
                        queueObservedMessage(node.closest('.mes'));
                        node.querySelectorAll?.('.mes').forEach(queueObservedMessage);
                    }

                    if (pendingObservedMessageIds.size > 0) {
                        scheduleProcessing();
                        return;
                    }
                }
            });

            observer.observe(chat, {
                childList: true,
                subtree: true,
                characterData: true,
            });

            chat.dataset.risuObserverAttached = 'true';
        };

        attachObserver();
        setTimeout(attachObserver, 500);
    }

    function init() {
        if (!window.SillyTavern || typeof window.SillyTavern.getContext !== 'function') {
            setTimeout(init, 100);
            return;
        }

        ensureRisuExtensionStyles();
        setupPortraitFix();
        hookPortraitNavigatorInteractions();
        createImportUI();
        injectRisuBgUI();
        hookGreetingSwipeGuard();
        hookTriggerButtons();
        hookRuntimeEvents();
        syncActiveRisuPortrait();
    }

    $(document).ready(() => {
        init();
    });
})();
