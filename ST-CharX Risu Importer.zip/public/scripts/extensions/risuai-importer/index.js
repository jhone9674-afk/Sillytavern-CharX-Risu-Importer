console.log("Deprecated index.js loaded - Browser cache is stale. Please clear cache.");
